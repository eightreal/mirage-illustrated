# 附录：官方 SDK 快照

![SDK 快照](../assets/sdk-package.png)

`cactus-sdk-bb822a3.tar.gz` 是 Cactus Compute 官方 `cactus-compute/cactus` 的原样 Git 源码导出：
`bb822a35983cf0ff942d67d46b8b79b535773b02`。包内保留 LICENSE、各版权头以及原有 NOTICE。
版本锚点：Python 项目声明版本 4.2.0，共享原生引擎下载清单固定到 4.1.4。Mirage Python wrapper 与早一版 `ce57892` 对比未变。

优先读 `cactus/agent/mirage.py`、`cactus/agent/runtime.py`、`cactus/cli/vision.py` 和 `tests/test_mirage.py`。
可通过 `tar -xzf cactus-sdk-bb822a3.tar.gz` 解包。源码包不是离线 wheel 集合，不包含 `mirage.cact` 或预编译原生引擎。
仓库其他模型的训练、微调和转换脚本保留原状，**不可当作 Mirage 训练管线**。发布文章原文未重新分发。

## 可直接打开的入口源码

以下文件从上方归档原字节提取，供在 GitHub 或本地编辑器浏览；它们不是可独立安装的 SDK。完整可构建源码仍以上方归档为准。

| 看什么 | 原样文件 |
|---|---|
| 图像入口、参数校验、`Mirage.describe/extract` | [mirage.py](source/cactus/agent/mirage.py) |
| 原生初始化、锁、ctypes 绑定 | [runtime.py](source/cactus/agent/runtime.py) |
| `options` 合并辅助函数 | [audio.py](source/cactus/agent/audio.py) |
| 视觉命令、参数解析 | [vision.py](source/cactus/cli/vision.py) · [parser.py](source/cactus/cli/parser.py) |
| 上游包装层单测 | [test_mirage.py](source/tests/test_mirage.py) |
| 许可证 | [Apache 2.0](source/LICENSE) |

[返回项目目录](../README.md)
