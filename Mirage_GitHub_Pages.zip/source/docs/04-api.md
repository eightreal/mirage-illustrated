# 04｜API、输入输出、CLI与离线调用

> 本章按已检查的官方代码解释接口，而不是推测其他视觉模型常见参数。示例分为“真实SDK用法”和“应用层示例”；没有执行真实模型推理的示例不冒称已在目标设备验证。

## 1. 版本与证据

![SDK、独立版本原生引擎与独立模型权重](../assets/api-01-version.png)

整理日期2026-11-20。固定官方仓库commit：`bb822a35983cf0ff942d67d46b8b79b535773b02`；模型revision：`76c1e9e53381aca8fc3843c636216c96ff220122`；对应下载器engine版本`4.1.4`。

本项目附带源码归档：`../upstream/cactus-sdk-bb822a3.tar.gz`。本次复核Mirage包装层、共享运行时、参数辅助函数及CLI视觉入口，与此前ce57892快照一致；新下载器固定engine `4.1.4`，engine revision `f4ab2741203a282c6e7b89983de2b5e5b2e805a8`，Mirage权重revision与哈希未变。不要把旧报告4.1.2当成本包当前engine。

直接检查：`cactus/agent/mirage.py`、`runtime.py`、`audio.py`中的`_options`、`cactus/cli/vision.py`、`parser.py`、`tests/test_mirage.py`及配套C头文件。选项名称另参照官方Mirage发布介绍与Python参考文章。以下是此固定版本合同，不代表任何未来版本都不变。

**调用包名与导入名不同：** 安装包为`cactus-compute`，Python中`import cactus`。

## 2. Python精确签名

![构造、extract 和模块入口如何通向实例 describe](../assets/api-02-python.png)

```python
class Mirage:
    def __init__(self, weights=None, buffer_size=16 * 1024 * 1024): ...

    def describe(
        self, image, *, options=None, language=None, keywords=None,
        width=None, height=None, **settings
    ): ...

    def extract(self, image, form, **options): ...

# 模块级缓存入口，公开为 cactus.describe

def describe(image, *, weights=None, **options): ...
```

### 2.1 构造函数

| 参数 | 含义 | 已核实行为 |
|---|---|---|
| `weights` | `.cact`路径，可为路径字符串/PathLike | 不传时调用模型下载器 |
| `buffer_size` | JSON输出字节缓冲容量 | 默认16×1024×1024；非正数被拒绝 |

这16MiB是输出缓冲，不是模型权重大小，也不是总RAM预算。请使用正整数；Python包装层只先检查正值，后续还由`ctypes`检查类型。

初始化通过共享动态库读取权重文件字节，然后调用`cactus_load(data,len(data))`。它不是在Python里实例化一个PyTorch网络，也不是把`config.json`传给引擎。

```python
from pathlib import Path
from cactus import Mirage

vision = Mirage(weights=Path("models/mirage.cact"))
result = vision.describe("images/example.png")
```

不应将`mirage.safetensors`或配置JSON当作此参数的兼容部署档案。不要根据构造签名编造`device="cuda"`、`npu=True`、`torch_dtype=`等参数。

### 2.2 `describe`

`image`支持下节五种形式。`language`与`keywords`为专门传给C ABI的参数，不与`options`在Python里自动合并。其余关键字`**settings`写入JSON选项对象。

```python
result = vision.describe(
    "images/example.png",
    language="en",
    keywords=["box", "label"],
    sections=["objects", "text"],
    fields=["bbox", "score", "mask"],
    conf=0.35,
    mask_format="polygons",
)
```

这里`0.35`是示例选择，不是声称官方默认阈值。`keywords`是提示参数，不保证只检测列表中的类别。

### 2.3 `extract`

包装层先验证`form`为非空dict，然后等价调用`describe(image,form=form,**options)`，不是第二套Python模型。

```python
form = {
    "object": {"enum": ["box", "bottle"]},
    "count": {"type": "integer", "minimum": 0, "maximum": 5},
}
result = vision.extract("images/example.png", form)
```

官方单元测试确认非空dict、enum与有界integer约束能保留顺序并送到引擎。完整约束解释在原生层；不要把Python只做非空dict校验误解为它已实现完整JSON Schema验证器。

短文本和引用框任务在官方说明中存在，但本次未确认全部`x-source`语法、组合规则与错误合同，因此不提供伪造的完整schema。需要这些高级形式时，应以匹配版本已经验证的原生样例扩充，不把猜测写入生产配置。

### 2.4 顶层缓存入口

```python
import cactus
result = cactus.describe("images/example.png", weights="models/mirage.cact")
```

该入口按权重路径键缓存`Mirage`对象。适合简单调用；大量处理建议显式持有一个实例。不要假定每次顶层调用都重新建独立引擎，也不要从这个接口推断存在官方batch API。

## 3. 五种图像输入

![五种 Python 图片输入汇入原图 RGB 缓冲](../assets/api-03-input.png)

| 形式 | 处理 | 注意事项 |
|---|---|---|
| 文件路径 | Pillow解码、EXIF转正、转RGB | 需Pillow可读取该格式 |
| PNG/JPEG等编码字节 | 包成BytesIO，再解码 | 不传width/height |
| Pillow Image | EXIF转正，再转RGB | 输出packed RGB bytes |
| NumPy风格数组 | 检查HWC、3通道、uint8，再`tobytes()` | 不自动BGR转RGB、不自动EXIF处理 |
| 裸RGB bytes | 显式宽高，检查长度为`3WH` | 不是PNG/JPEG压缩文件内容 |

```python
from pathlib import Path
from PIL import Image
import numpy as np

# A 文件路径
r1 = vision.describe(Path("images/example.png"))

# B 编码图片字节：不填显式尺寸
encoded = Path("images/example.png").read_bytes()
r2 = vision.describe(encoded)

# C Pillow图像
with Image.open("images/example.png") as image:
    r3 = vision.describe(image)

# D RGB uint8数组
rgb = np.zeros((240, 320, 3), dtype=np.uint8)
r4 = vision.describe(rgb)

# E 裸RGB：320宽，240高，3通道
r5 = vision.describe(rgb.tobytes(), width=320, height=240)
```

显式提供`width`或`height`会走裸RGB分支，必须两个都提供。宽高应为正整数，数据只能是bytes/bytearray/memoryview，长度必须精确等于`width*height*3`。不要把“传了压缩图像字节，同时填原图宽高”当成合法用法。

数组必须为`(height,width,3)`与`uint8`。官方测试覆盖非连续数组通过`tobytes()`正确展开；浮点数组或灰度二维数组被拒绝。OpenCV常见BGR应在应用侧明确转换：

```python
# 若bgr确实来自BGR约定的输入源
rgb = bgr[..., ::-1].copy()
result = vision.describe(rgb)
```

不要提前把像素缩放到[-1,1]后仍当作RGB uint8送入。SDK负责解码成原图RGB；模型内部画布预处理是另一步，不是`Image.convert("RGB")`本身。

## 4. 参数合并与编码：几个常见陷阱

![重名参数的键交集导致 ValueError](../assets/api-04-options.png)

包装层按以下顺序处理：

1. `options`必须为dict或None。
2. 复制它，检查与`**settings`是否有重复键。
3. 如果重键，抛`ValueError`，**不是关键字覆盖字典**。
4. 使用`json.dumps(...,ensure_ascii=False,allow_nan=False)`编码UTF-8。
5. 转换图像与语言/关键词参数，绑定引擎，调用C函数。

```python
# 正确：不同键
vision.describe("image.png", options={"sections": ["objects"]}, conf=0.4)

# 错误：conf重复，包装层直接拒绝
# vision.describe("image.png", options={"conf": 0.4}, conf=0.6)

# 错误：NaN不能序列化为此请求JSON
# vision.describe("image.png", conf=float("nan"))
```

`language`非空时编码UTF-8；`keywords`若为字符串则直接编码，若为字符串可迭代对象则用换行拼接。空值转换为NULL。不要用整数列表或混合类型关键词期待包装层替你转字符串。

SDK没有对每个原生选项做完整白名单校验；一个拼错的关键字可能直到引擎才报错。Python接受`**settings`不等于原生支持任何同名参数。

## 5. 已披露的原生选项与未知边界

![阈值筛选三个检测候选的分数示意](../assets/api-05-filter.png)

| 键 | 用途 | 说明 |
|---|---|---|
| `sections` | 选择返回分区 | 官方示例含objects、text |
| `fields` | 选择字段 | 官方示例含bbox、score、mask |
| `conf` | 物体候选分数阈值 | 不等于名称/关系的联合置信度 |
| `text_conf` | 文字候选阈值 | 不等于字符串整体正确率 |
| `max_objects` | 对象输出数量控制 | 不把它当作改变模型内部结构 |
| `max_text_lines` | 文字行数量控制 | 不应从config的reads字段推断固定八行上限 |
| `max_tokens` | 语义生成长度控制 | 精确默认值与范围由原生版本决定 |
| `mask_format` | 掩码表示选择 | largest（默认）、polygons、merged、bitmap |
| `form` | 表单请求 | 通过extract或describe传入 |

`nms`等名称曾出现在资料中，但完整类型与合同未确认，本文不把它写成一个任意float或bool示例。上述键的默认阈值、所有枚举与所有组合限制没有在包装源码里完整定义，不能由“常见检测器通常这样”补全。

中文可在Python和JSON传输，不等于模型支持中文OCR。官方发布的OCR为拉丁字符集合；描述语言支持范围与传输编码是两件事。

## 6. 返回值：先保留原始结果，再加应用约束

![归一化框在原图上的两个角点](../assets/api-06-coordinates.png)

`describe`在C调用成功后，将输出缓冲UTF-8解码并`json.loads`，返回相应Python对象。官方正常结果为结构化记录，但包装层本身不验证完整输出schema。

以下是**应用自编的简化示意**，不是运行模型取得的真实输出，也不是完整schema：

```json
{
  "objects": [
    {"id": 1, "name": "box", "bbox": [250, 250, 625, 750], "score": 0.72}
  ],
  "text": []
}
```

公开框坐标按原图每条轴分别归一化到0–1000。对上例640×480原图：

```text
x1 = 250/1000*640 = 160
 y1 = 250/1000*480 = 120
x2 = 625/1000*640 = 400
 y2 = 750/1000*480 = 360
```

只有在确认字段实际为四元素`xyxy`后，才使用下列辅助函数；不能给未知格式自动套用。

```python
def normalized_xyxy_to_pixels(box, width, height):
    if len(box) != 4 or width <= 0 or height <= 0:
        raise ValueError("invalid box/image size")
    x1, y1, x2, y2 = map(float, box)
    if not (0 <= x1 <= x2 <= 1000 and 0 <= y1 <= y2 <= 1000):
        raise ValueError("invalid normalized xyxy")
    return [x1 * width / 1000, y1 * height / 1000,
            x2 * width / 1000, y2 * height / 1000]
```

官方实例掩码专题明确：bitmap 返回原图尺寸的未压缩列优先 RLE，包含按高、宽排列的 size 及从背景 run 开始的 counts；它不是逐像素数组。largest（默认）取最大外轮廓；polygons 保留各个独立外轮廓；merged 用桥把外轮廓串起，可能跨过背景。多边形模式不保留孔洞边界。完整嵌套字段和表单概率字段名仍以此版本实发结果为准。首次接入应保存小样图的真实返回，按版本增加校验。

检测分数是候选区域分数，不是名称、掩码、属性和关系一起正确的概率。生成的reasoning也不是经验证的内部计算日志。

## 7. 错误、锁与缓存

![线程 A、B 先后获得共享锁并推理](../assets/api-07-lock.png)

| 情况 | 已核实行为 |
|---|---|
| options不是dict | TypeError |
| options与settings重键 | ValueError |
| JSON中NaN/Inf | allow_nan=False导致ValueError |
| 裸RGB宽高/长度不匹配 | ValueError或输入类型错误 |
| 数组维度/通道/dtype不符 | ValueError |
| form为空或非dict | ValueError |
| cactus_load或cactus_describe返回负值 | RuntimeError，取cactus_last_error文本 |
| 返回缓冲不是合法UTF-8/JSON | 对应解码/JSON异常 |
| 路径、依赖或库加载错误 | 相应文件/导入/动态库异常 |

原生失败时包装层先抛错，不会把上一次缓冲内容当成这一次结果解析。不要在应用层捕获所有异常后返回“最近成功结果”，这会让失败图片看起来获得了正确识别。

共享运行时用`threading.RLock()`保护。Mirage与相关引擎调用被串行化；多开Python线程不等于多份模型并行推理。`_bind`可在已有锁中重入，因此需要RLock而非普通不可重入锁。

固定版本没有公开的Mirage `close()`、`reset()`或上下文管理器合同；不要写`with Mirage(...) as model:`。原生库存在的其他函数也不自动等于Mirage实例方法。

## 8. CLI

![describe 和 extract 命令共享模型入口](../assets/api-08-cli.png)

固定版本提供：

```bash
cactus mirage describe image.png --weights models/mirage.cact \
  --language en --keywords box label \
  --options '{"sections":["objects","text"],"conf":0.35}'

cactus mirage extract image.png --weights models/mirage.cact \
  --form form.json --options '{}'
```

Windows shell的引号转义规则不同；不能把Bash单引号示例原样假定适用于所有启动环境。`--form`指定UTF-8 JSON文件；`--options`必须解码为JSON对象。

CLI实现会在extract模式读取form文件并设置`options["form"]`，再调用`model.describe`。这与直接调用`extract()`的包装校验路径不完全相同，CLI不是另一个训练入口。

标准输出为`ensure_ascii=False,indent=2`的JSON；应用可以重定向保存。错误输出和退出状态应单独收集。

## 9. 批处理是应用循环，不是假装官方batch接口

![逐张调用时，失败样本拥有独立 JSONL 结果行](../assets/api-09-batch.png)

```python
import json
import time
from pathlib import Path
from cactus import Mirage

vision = Mirage(weights="models/mirage.cact")
with Path("results.jsonl").open("w", encoding="utf-8") as out:
    for path in sorted(Path("images").glob("*.png")):
        start = time.perf_counter()
        try:
            result = vision.describe(path, sections=["objects", "text"])
            row = {"image": str(path), "ok": True, "result": result}
        except Exception as exc:
            row = {"image": str(path), "ok": False,
                   "error_type": type(exc).__name__, "error": str(exc)}
        row["elapsed_ms"] = (time.perf_counter() - start) * 1000
        out.write(json.dumps(row, ensure_ascii=False) + "\n")
        out.flush()
```

初始化时间与稳态调用分开计。比较性能时固定分辨率、文字数量、mask选项、阈值、生成长度和运行设备，不将官方某次NPU测量当成本机保证。

## 10. 离线准备

![离线机需要 wheel 及依赖、原生引擎和模型权重](../assets/api-10-offline.png)

必须准备三个部分：Python包及依赖、匹配目标平台的运行库、对应`.cact`。只有本Markdown项目不等于已经具备可运行推理环境。

联网准备机示例：

```bash
# 从项目根目录运行，用随包固定源码构建wheel及收集依赖
python -m pip wheel ./upstream/cactus-sdk-bb822a3.tar.gz --wheel-dir ./wheelhouse
# 准备机在独立虚拟环境中安装这组wheel，再使用对应下载器
python -m pip install --no-index --find-links ./wheelhouse cactus-compute
cactus fetch --out ./engine
cactus download mirage --out ./models
```

这些步骤需要联网准备依赖和下载资源；模型推理可以在准备完成后离线进行，不需要把用户图片上传。源码归档不包含全部wheel、原生运行库和模型权重。

这组命令默认针对准备机平台。若目标操作系统、CPU、Python ABI不同，应下载匹配目标的依赖和运行库，而不是直接复制本机二进制。

目标离线机示例：

```bash
python -m pip install --no-index --find-links ./wheelhouse cactus-compute
export CACTUS_LIB_PATH=/absolute/path/to/libcactus.so
export CACTUS_MIRAGE_WEIGHTS=/absolute/path/to/mirage.cact
export HF_HUB_OFFLINE=1
export CACTUS_TELEMETRY=0
# 也可按部署策略设置 DO_NOT_TRACK=1
```

在导入或初始化前设置。macOS/Windows使用匹配`.dylib`/`.dll`与对应环境变量语法。`HF_HUB_OFFLINE=1`不会凭空下载缺失文件，正式离线前应实际断网验证。

固定revision的`.cact` SHA-256：

```text
4249a0f7515272ff76b9414bec17d7e7daf84b15b66c7fb4f17fce1e66f9f237
```

未来换版本时哈希也会合法变化。校验失败先核对版本，不能立即断言文件恶意。

Android下载产物与Python Linux wheel不能混为一谈。Bionic不同于glibc/musl，已检查下载器明确区分；此版本Android原生产物路线包括静态库和CLI，不能直接假定Termux可加载普通Linux `.so`或自动启用NPU。

## 11. C ABI

![模型字节和 RGB 图像走不同 C API，成功后解析输出](../assets/api-11-abi.png)

固定engine头文件中的入口：

```c
int cactus_describe(
    const unsigned char* rgb,
    int width,
    int height,
    const char* options,
    const char* language,
    const char* keywords,
    char* out,
    int out_capacity
);
```

调用顺序：读取并加载`.cact`字节，准备连续RGB，准备UTF-8参数与可写输出缓冲，调用，先检查返回状态，再解析缓冲。`cactus_load`接受模型内容字节及长度，不是路径字符串。

做JNI、Swift或其他绑定时必须处理所有内存寿命、空指针、长度与线程约束。Python中的RLock不会替另一个原生调用者提供锁。不要将Python示例当作完整原生线程安全合同。

## 12. 最小接入验收清单

![离线接入从校验文件到目标设备并发实测](../assets/api-12-checklist.png)

- [ ] 权重、运行库、SDK版本及哈希已记录。
- [ ] 原图方向、RGB/BGR、宽高与输入类型已确认。
- [ ] JSON参数无重键、无NaN、无猜测开关。
- [ ] 对真实返回按所用字段建立校验，保留原始结果。
- [ ] 异常不会返回前一张图的结果。
- [ ] 使用模型支持的语言/字符范围，不把UTF-8等同中文OCR。
- [ ] 离线机器经过断网启动与推理测试。
- [ ] 并发、内存和延迟均为目标设备实测，而不是文档推测。

本章代码块做静态语法核查；官方测试中的mock引擎验证的是参数转发和包装层行为，不是模型识别精度或原生后端可用性。

[返回项目目录](../README.md)
