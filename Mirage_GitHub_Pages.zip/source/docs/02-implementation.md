# Cactus Mirage 模型结构与数学原理详细报告

> 面向离线阅读的中文技术报告。结合发布时公开资料以及本包固定模型版本核验。本文不是官方文章翻译，也不是模型反向工程结果；依据公开配置、官方架构 Maths 面板、专题文章和 Python 接口源码重新组织，公式配有中文变量解释及原创算例。没有运行模型推理，不能据此声称复现了官方精度或速度。
>
> **阅读标记**：**[官方]** 表示公开的一手配置或公式；**[推导]** 表示据这些条件进行的数学推演；**[示意]** 表示解释概念而非逐行实现。公式中的维度默认不写 batch 轴。空间特征用 `H×W×C`，矩阵计算按列向量说明。

## 目录

1. [模型定位与整条计算图](#section-1)
2. [记号与配置全景](#section-2)
3. [输入、letterbox 和有效区域](#section-3)
4. [五级卷积 stem](#section-4)
5. [十六个空间 body blocks](#section-5)
6. [HConvGLU：Walsh 基中的带状门控](#section-6)
7. [十二个注意力块与 register tokens](#section-7)
8. [Level memory 与特征金字塔](#section-8)
9. [物体及文字检测](#section-9)
10. [区域槽与图像记忆](#section-10)
11. [八层语义解码器总览](#section-11)
12. [Engram 记忆分支](#section-12)
13. [自注意力与视觉交叉注意力](#section-13)
14. [Hadamard MLP](#section-14)
15. [四通道 mHC 残差路由](#section-15)
16. [共享原型实例分割](#section-16)
17. [独立 OCR reader 与 CTC](#section-17)
18. [form 有界决策](#section-18)
19. [运行时装配与完整算例](#section-19)
20. [初始化、量化与工程边界](#section-20)
21. [核验表与来源](#section-21)

---

<a id="section-1"></a>

## 1. 模型定位与整条计算图

![图 1：总模型图：共享编码器、空间头和语义及 OCR 读出](../assets/arch-overview.png)

Mirage 的核心不是“一个小聊天模型把所有视觉信息写成文字”，而是把任务分工：空间模块给出几何，OCR 模块读字符，解码器输出紧凑语义，运行时拼成应用可用的记录。

**[官方] 总依赖关系，用本文符号重述：**

$$
(E,D)=\mathrm{Encoder}(I),\quad B=\mathrm{Detector}(D),
$$
$$
A=\mathrm{Masks}(D,B;S_4),\quad R=\mathrm{OCR}(I,B_{\mathrm{text}}),
$$
$$
M=\mathrm{Memory}(E,D,B),\quad Y=\mathrm{Decoder}(M),
$$
$$
J=\mathrm{Assemble}(Y,B,A,R).
$$

- $I$：原始 RGB 图像；$E$：粗粒度图像记忆；$D$：细粒度空间特征。
- $B$：物体框与文字框；$A$：对象掩码；$R$：OCR 字符串。
- $M$：图像与区域槽构成的解码记忆；$Y$：紧凑语义序列；$J$：JSON 结果。
- $S_4$：四倍下采样的 stem 特征，供掩码分支补细节。

这是一张依赖图，不保证所有分支同时执行。请求字段会影响工作量。**OCR 字符串不反馈给语义解码器；form 模式也不运行 OCR reader。** 准确文字驱动的判断，应由应用消费 OCR 结果，而非默认表单已读到该结果。

来源：结构化感知。

<a id="section-2"></a>

## 2. 记号与配置全景

![图 2：三个空间张量：位置数与每位置通道数](../assets/impl-02-config.png)

### 2.1 已公开的关键尺寸

| 部分 | 配置/尺寸 | 不应误读为 |
|---|---|---|
| 输入画布 | 512×512 | 原图必须是正方形 |
| stem 通道 | 32、64、128、256、512 | 五个独立模型 |
| 粗图像网格 | 16×16×512，即256个位置 | 256个固定物体类别 |
| 空间主体 | 16 blocks | 16种视觉任务 |
| 编码器注意力 | 12 blocks，Q heads=4，KV heads=1 | 解码器的头数配置 |
| 编码器 qk/v 维度 | 32 / 64 | 每个 token 总维度 |
| registers | 4×512 | 4个输出对象 |
| neck 输出 | 64×64×128 | 原图64像素分辨率 |
| 物体/文字候选预算 | 64 / 32 | 保证检测到这么多个 |
| 语义解码器 | 8层，dim=512，KV heads=2 | 任意对话能力 |
| 解码器 qk/v | 48 / 64 | 编码器注意力维度 |
| decoder temporal taps | 3 | OCR的滑窗数 |
| residual lanes | 4 | 四次独立推理 |
| Engram | orders=[2,3]，hashes=2，slots=18432 | 外部文档向量数据库 |
| OCR | dim=384，4 blocks，窗口48×320 | 最多只能读320像素的长行 |
| 掩码原型 | 128×128×32 | 最多32个对象 |
| 配置 max_tokens | 1536 | 已证实的通用聊天上下文 |

**[官方]** 配置还包含 `sites=[3,7]`、`rope=100000`、`enc_rope=10000`、`pooled_slots=true`、`grn=true`、`level_memory=true` 等。`sites` 表示 Engram 放置位置的配置值；未在本文将其转述成“第几层”，以免混淆零基/一基索引。

模型快照：`76c1e9e53381aca8fc3843c636216c96ff220122`。本报告使用该研究期间核验到的公开配置及随后同一版本的官方说明。

来源：官方 config.json。

### 2.2 基础算子

**[官方]** 通道归一化采用带可学习缩放的 RMS 形式：

$$
\mathcal N_s(x)=\frac{(1+s)\odot x}{\sqrt{\frac1n\sum_{c=1}^n x_c^2+\epsilon}},\qquad\epsilon=10^{-6}.
$$

这里 $s$ 是参数向量；$1+s$ 而非直接 $s$ 是官方表达。每个位置沿通道轴归一化，不意味着把整张图的空间位置一起归一化。

$$
\sigma(z)=\frac1{1+e^{-z}},\quad\mathrm{SiLU}(z)=z\sigma(z),
$$
$$
\mathrm{GELU}(z)\approx\frac z2\left[1+\tanh\left(\sqrt{2/\pi}(z+0.044715z^3)\right)\right].
$$

$\odot$ 表示对应位置相乘；$[a;b]$ 表示拼接；DW 是逐通道卷积；PW 是逐位置通道投影；上采样 $\uparrow_2$ 将空间长宽各增大两倍。

来源：发布页 Maths 面板。

<a id="section-3"></a>

## 3. 输入、letterbox 和有效区域

![图 3：原图、512 画布与粗网格有效区域](../assets/impl-03-letterbox.png)

设原图高宽为 $H,W$。**[官方]** 缩放比例为

$$
\rho=\frac{512}{\max(H,W)}.
$$

缩放后的有效尺寸为 $h,w$，再装入512画布；像素进入网络前变为

$$
I'=\mathrm{Letterbox}_{512}(I)/127.5-1.
$$

这把0–255像素映射到约−1–1。不能将该公式套在已经标准化的浮点输入上再做一遍。

**[官方]** 在下采样倍数 $s$ 上，有效位置可用

$$
m_s(i,j)=\mathbf1\{i<\lceil h/s\rceil,\ j<\lceil w/s\rceil\}
$$

表示。该写法对应官方坐标约定，移植时应匹配真实 padding 方向及舍入方式，而不是自行更换成任意居中填充后仍沿用同一掩码。

**[推导算例]** 1920×1080 的横图缩至512×288；画布仍是512×512。粗网格有效区域约16×9，剩余不是“黑色物体”，而应被有效掩码屏蔽。OCR 后续依旧从原始1920×1080图裁字，避免全图压缩造成的小字细节丢失。

来源：发布页 Maths、OCR 说明。

<a id="section-4"></a>

## 4. 五级卷积 stem

![图 4：五级下采样、独立参数块及编码输出 E](../assets/16_stem_backbone.png)

### 4.1 精确尺寸链

**[官方]** 五级均将空间下采样两倍：

```text
512×512×3
  → 256×256×32     F1，stride 2
  → 128×128×64    F2 = S4
  →  64×64×128    F3 = S8
  →  32×32×256    F4 = S16
  →  16×16×512    F5
  → 256×512       展平后进入主体
```

这里 $S_4$ 中的4是下采样倍数，不是第四层。

### 4.2 公式

首级是普通3×3卷积：

$$
F_1=m_2\odot\mathcal N(\mathrm{Conv}_{3\times3,s=2}(I')).
$$

后续四级由深度卷积和逐点投影组成：

$$
F_j=m_{2^j}\odot\mathcal N\{\mathrm{PW}_j[
\mathrm{DW}_{3\times3,s=2}(\mathrm{SiLU}(F_{j-1}))]\},\quad j=2,\ldots,5.
$$

$$
X^{(0)}=\mathrm{flatten}(\mathrm{SiLU}(F_5))\in\mathbb R^{256\times512}.
$$

**[解释]** 深度卷积让每个通道观察附近空间；逐点矩阵在同一位置混合通道。二者不是同一件事。相较完整3×3的 $C_{in}\to C_{out}$ 卷积，其参数量从约 $9C_{in}C_{out}$ 降到 $9C_{in}+C_{in}C_{out}$，但不能从参数比直接推出实际延迟比。

来源：发布页 Maths。

<a id="section-5"></a>

## 5. 十六个空间 body blocks

![图 5：Body 的逐通道空间门控、HConvGLU 和 GRN](../assets/impl-05-body.png)

**[官方]** stem 后有16个卷积主体块；每块包括空间门控混合与 HConvGLU 通道混合。

先规范化：$Z=\mathcal N(X)$。空间两支：

$$
v=\mathrm{DW}_v(Z)+b_v,\quad g=\mathrm{DW}_g(Z)+b_g,
$$
$$
\widetilde X=X+m_{32}\odot\mathrm{DW}_o[v\odot\mathrm{SiLU}(g)].
$$

随后在每个位置 $p$ 上做通道混合：

$$
H_p=\mathrm{HConvGLU}(\mathcal N(\widetilde X_p)).
$$

再做 Global Response Normalisation（GRN）：

$$
r_c=\sqrt{\sum_p(m_pH_{pc})^2+\epsilon},\quad\bar r=\frac1d\sum_cr_c,
$$
$$
\mathrm{GRN}(H)_{pc}=H_{pc}+\gamma_cH_{pc}\frac{r_c}{\bar r+\epsilon}+\beta_c,
$$
$$
X^+=\widetilde X+m_{32}\odot\mathrm{GRN}(H).
$$

**[解释]** 通道 $c$ 的响应幅度 $r_c$ 跨空间统计，因此 GRN 不是纯粹“每个位置各做各的”。RMSNorm 与 GRN 名字都带 norm，但统计轴不同。$\gamma,\beta$ 是学习参数；GRN 并非简单把所有通道强行除到相同能量。

来源：发布页 Maths、HConvGLU。

<a id="section-6"></a>

## 6. HConvGLU：Walsh 基中的带状门控

![图 6：Walsh 基空间的三组带状矩阵和门控](../assets/impl-06-hconv.png)

### 6.1 解决什么问题

通道维 $d=512$ 上，标准两矩阵FFN若扩张到 $4d=2048$，忽略偏置需要

$$
d(4d)+(4d)d=8d^2=2,097,152
$$

个权重。HConvGLU 不学习任意稠密映射，而先固定换基，再学窄带映射。

### 6.2 Walsh 变换不是随便一个 Hadamard 排序

**[官方]** 此处 $W$ 是归一化、按 sequency 排列的 Walsh 矩阵。对该特定排列，

$$
W^TW=I,\quad W^T=W,\quad W^{-1}=W.
$$

Sequency 是行向量的符号变化次数；它不是图像空间频率坐标。不能把某种自然序 Hadamard 输出不加重排就代替。

**[推导]** 正交性保证 $\|Wx\|_2=\|x\|_2$。这只说明变换保能量，不保证后面的学习映射保能量或保精度。

### 6.3 带状算子

$$
(Bu)_j=\sum_{t=-32}^{32}w_{j,t}u_{j+t},\qquad
u_i=0\ \text{if }i\notin[0,511].
$$

每个输出 $j$ 有自己65个权重，带宽65；不是跨输出共享卷积核，也不是循环回绕。一个中心位置可看自己左右各32个变换系数。

### 6.4 完整前向公式

**[官方]**

$$
u=Wx,
$$
$$
a=B_gu+b,\quad v=B_vu,
$$
$$
y=WB_o[\mathrm{GELU}(a)\odot v].
$$

仅 gate 分支这里有偏置 $b$。先生成门控和 value，再逐通道相乘，再 output band，最后逆变换。GELU 不限制在0–1，所以不是概率门。残差与规范化属于外围 block，不该多塞进这个算子公式。

**[原创二通道示意]** 取 $W=\frac1{\sqrt2}\begin{bmatrix}1&1\\1&-1\end{bmatrix}$，$x=(1,1)^T$，则 $u=(\sqrt2,0)^T$。令三个 $B$ 都是单位矩阵且偏置0，就得到 $y=W[\mathrm{GELU}(u)\odot u]$。这是帮助观察乘性门的玩具，不是实际512维权重或推理样例。

### 6.5 为什么既能全局混合，又不是任意稠密层

单独考察一个带状线性映射，换回原坐标后为 $WBW$。完整 GLU 仍含乘性门，不能把它直接简化成这一个矩阵。即使 $B$ 带状，$WBW$ 也可能稠密，因为每个 Walsh 基向量跨全部通道。可是 $B=I$ 时结果仍是 $I$，不能说它必然所有输出依赖所有输入。

**[推导]** $\mathrm{rank}(WBW)=\mathrm{rank}(B)$，可满秩，但自由度仍受带约束。满秩不等于能表示任意512×512矩阵。

### 6.6 存储和运算核算

$$
512\cdot65=33,280\quad\text{每带存储槽位}
$$
$$
33,280-32\cdot33=32,224\quad\text{每带非越界有效系数}
$$
$$
3\cdot33,280+512=100,352\quad\text{参数/模块}
$$

28个模块对应16个 body 加12个 attention，总计2,809,856参数。三个带的有效MAC为96,672/向量；两个蝶形变换另需 $2\cdot512\log_2512=9,216$ 次加减，还没计激活、偏置、逐点乘和外围归一化。

**移植陷阱**：CPU 可使用未归一化蝶形 $S=\sqrt{512}W$，并把三个带各除以 $\sqrt{512}$。这与原式等价，偏置不除。若同时使用归一化蝶形和已经折叠缩放的带，会重复缩放。

来源：HConvGLU 一手推导。

<a id="section-7"></a>

## 7. 十二个注意力块与 register tokens

![图 7a：256 个图像位置加 4 个 register 经过注意力](../assets/impl-07-register.png)

![图 7b：注意力内部 Q、K、V 和输出投影的形状](../assets/15_block_dimensions.png)

### 7.1 顺序与尺寸

**[官方 Maths 新核验]** 16个 body 之后，拼上4个可学习 registers：

$$
Z^{(0)}=[X^{(16)};R],\quad R\in\mathbb R^{4\times512}.
$$

因此注意力阶段最多处理260个位置：256个网格位置加4个寄存位置。接着12个注意力块。之前只凭文字配置而不画明确串行顺序是保守做法；Maths 面板给出了这里的顺序依据。

### 7.2 GQA

**[官方]** 4个 query heads 共用1个 KV head；每个Q/K维度32，每个V维度64。

$$
z=\mathcal N_{pre}(Z),\quad q_{p,h}=\mathcal R_p\mathcal N_q(W_{Q,h}z_p),
$$
$$
k_{j,g}=\mathcal R_j\mathcal N_k(W_{K,g}z_j),\quad v_{j,g}=W_{V,g}z_j.
$$

$\mathcal R$ 表示位置旋转，$g(h)$ 将 query head 对应到KV组。

$$
\alpha_{pjh}=\mathrm{softmax}_j\left(\frac{q_{p,h}^Tk_{j,g(h)}}{\sqrt{32}}+M_{pj}\right),
$$
$$
a_p=\mathrm{concat}_{h=1}^{4}\sum_j\alpha_{pjh}v_{j,g(h)},
$$
$$
\mathcal A(z)_p=W_O[\sigma(W_Gz_p)\odot a_p].
$$

拼接前每头64维，拼接后256维，再输出回512维。$M$ 是有效性掩码，不是模型自行生成的“注意力置信度”。

残差为

$$
\widetilde Z=Z+m\odot\sigma(a_\ell)\mathcal N_{post}(\mathcal A(z)),
$$
$$
Z^+=\widetilde Z+m\odot\mathrm{HConvGLU}(\mathcal N(\widetilde Z)).
$$

此处没有 body 中的GRN包装。registers 参加注意力，之后送入空间头前移除，不成为检测物体或图像额外像素。

**[解释]** Q决定“当前位置在寻找什么”，K是被查找位置的匹配特征，V是要汇聚的内容。这是对计算作用的比喻，不表示每头有人工命名的固定功能。

来源：发布页 Maths、HConvGLU。

<a id="section-8"></a>

## 8. Level memory 与特征金字塔

![图 8a：Level memory 对同位置同通道加权求和](../assets/impl-08-level.png)

![图 8b：D 的明确来源：E 与 S16、S8 两级融合](../assets/17_d_fusion.png)

### 8.1 Level memory 不增加 token 数

**[官方]** 最终粗图融合 earlier levels：

$$
E=m_{32}\odot\left[\mathcal N(Z^{(12)}_{grid})+
\sum_{\ell=0}^{11}g_\ell\odot\mathcal N_\ell(Z^{(\ell)}_{grid})\right].
$$

$g_\ell\in\mathbb R^{512}$，$E\in\mathbb R^{256\times512}$。这些门是在通道上混合各层，不是把12层全部拼成3072个图像 token，也不是检索外部图像库。

### 8.2 Neck

先定义带残差的局部块：

$$
\mathcal B(F)=F+\mathrm{PW}[\mathrm{DW}_{3\times3}(\mathrm{SiLU}(\mathcal N(F)))].
$$

然后从16网格走到32、64：

$$
T_{32}=\mathcal B[\uparrow_2(W_EE)+W_{16}S_{16}],
$$
$$
D=\mathrm{SiLU}\left(\mathcal N\left[
(\mathcal B_3\circ\mathcal B_2\circ\mathcal B_1)
(\uparrow_2T_{32}+W_8S_8)\right]\right).
$$

输出 $D$ 为64×64×128。加法前通过投影匹配通道；不能把512通道粗图直接与256通道 stem 特征相加。

**[解释]** 粗图带大范围上下文，早期 stem 保留更密的位置细节。上采样本身不会凭空恢复丢失信息，融合早期特征才给细节一个入口。

来源：发布页 Maths、实例分割。

<a id="section-9"></a>

## 9. 物体与文字检测

![图 9：检测峰值、亚格点中心和边界框原创算例](../assets/impl-09-det.png)

### 9.1 每个空间位置预测什么

**[官方]** 对两类区域（物体、文字）预测热图 $h$、宽高原值 $\omega$、中心偏移 $\delta$：

$$
(h,\omega,\delta)=W_{det}D+b_{det},\quad p_{ijc}=\sigma(h_{ijc}).
$$

在网格行 $i$、列 $j$：

$$
x_c=j+\delta_x,\quad y_c=i+\delta_y,\quad
w_b=|\omega_w|,\ h_b=|\omega_h|,
$$
$$
b=\frac1{64}(x_c-w_b/2,\ y_c-h_b/2,\ x_c+w_b/2,\ y_c+h_b/2).
$$

它是区域提议，不是固定类别分类器；“猫”“路牌”等名字由解码器提供。

### 9.2 筛选与坐标

3×3局部极大值、分数阈值、候选预算共同筛选，预算为物体64、文字32；框裁到有效图像并映回原图。公开框使用每轴0–1000。

**[推导算例]** 原图宽1200、高800；输出框 `[250,125,750,625]` 对应约左300、上100、右900、下500像素。整数舍入应由实际运行时约定决定，不应把这一算例当逐像素复现。

**[示意换算]** 若预处理缩放为 $\rho$，填充偏移为 $o_x,o_y$，则原图坐标是 $(x_{canvas}-o_x)/\rho$、$(y_{canvas}-o_y)/\rho$。保留偏移符号是为了说明移植时不能忘掉 padding；实际值应匹配引擎而非猜测。

**边界**：相邻中心可被局部峰值规则压掉；预算会截断密集场景；低分不等于不存在。score 是区域热图分数，不是名字、属性、掩码同时正确的联合概率。

来源：结构化感知、发布页 Maths。

<a id="section-10"></a>

## 10. 区域槽与图像记忆

![图 10：三个来源生成一个区域槽](../assets/impl-10-slots.png)

### 10.1 为什么不把框坐标当普通文字写出来

语言序列可以使用一个区域引用 token，运行时再把该引用绑定到几何。这样把“哪里”和“叫什么”分开，同时保留对应关系。

**[官方]** 对第 $k$ 个候选，取中心细特征 $f_k\in\mathbb R^{128}$、框四角编码 $\phi(b_k)\in\mathbb R^{64}$、框内粗图池化 $\bar e_k\in\mathbb R^{512}$：

$$
z_k=W_s[f_k;\phi(b_k)]+W_p\bar e_k,
$$
$$
s_k=\mathcal N(z_k)+\sqrt{512}\,T_{r_k}.
$$

$T_{r_k}$ 是引用 token 的嵌入。框编码的4个坐标各用8个正弦、8个余弦，因此共 $4\times16=64$ 维：

$$
\phi(b)=\mathrm{concat}_{c=1}^4\left[(\sin(2^r\pi b_c))_{r=0}^7;
(\cos(2^r\pi b_c))_{r=0}^7\right].
$$

构成视觉记忆：

$$
M=[E+\sigma(a_{pos})\mathrm{PE}_{2D};s_1;\ldots;s_K].
$$

如果保留 $K$ 个区域槽，长度为256+$K$。不要把配置 `slots=18432` 当成这里的视觉区域槽数；18432是 Engram 哈希表容量。

### 10.2 有限引用约束

没有候选支撑的引用 token 被屏蔽为 $-\infty$ logit。**这只禁止引用不存在的槽，不禁止指错已有槽。** 一个人和一辆车都检测正确，也仍可能被错配名称。

来源：结构化感知、发布页 Maths。

<a id="section-11"></a>

## 11. 八层语义解码器总览

![图 11：视觉记忆、语义解码器和区域引用](../assets/14_model_decoder.png)

**[官方]** 维度512；8层；4条 mHC 残差 lanes；内部包括指定层的Engram、自注意力、视觉交叉注意力、Hadamard MLP。

```text
历史 token → embedding → 复制到4条 residual lanes
  ↓ 每层：mHC读出为单路512维
  [指定sites的Engram] → self-attention → cross-attention → HMLP
  ↓ mHC将本层增量写回4路
  重复8层
  ↓ lanes求均值 → 归一化 → tied embedding输出logits
  ↓ 词表合法性掩码 → 下一个token
```

初始化：

$$
e_t=\sqrt{512}\,T_{y_t},\qquad X_t^{(0)}=\mathbf1_4e_t^T\in\mathbb R^{4\times512}.
$$

末端：

$$
h_t=\mathcal N\left[\tfrac14(X_t^{(8)})^T\mathbf1_4\right],\quad\ell_t=Th_t.
$$

同一个 $T$ 用于输入嵌入和输出投影，即 tied embeddings。

$$
p(y_{t+1}\mid y_{\le t},I)=\mathrm{softmax}(\ell_t+M_{vocab}).
$$

语义是自回归的；坐标与掩码不是由该序列逐数字/逐像素生成。输出格式更紧凑不代表不会漏项、重复或关系幻觉。

来源：发布页 Maths。

<a id="section-12"></a>

## 12. Engram：局部 token 组合的参数记忆

![图 12：Engram 哈希查表、门控和残差注入](../assets/impl-12-engram.png)

### 12.1 哈希查表

**[官方]** 取2-gram与3-gram，每种两个哈希：

$$
i_{o,h}(t)=\mathrm{hash}_{o,h}(y_{t-o+1:t})\bmod18432,
\quad o\in\{2,3\},\ h\in\{1,2\}.
$$

四个查表向量拼成 $e_t^{eng}$。它依赖历史 token 组合，不是输入照片的OCR字符串，不是联网搜索。

### 12.2 门控注入

$$
k_t=W_ke_t^{eng},\qquad
v_t=\sum_{j=0}^{3}\tau_j\odot W_ve_{t-3j}^{eng},
$$
$$
\alpha_t=\sigma\left(\frac{\widehat u_t^T\widehat k_t}{\sqrt{512}}\right),
\quad u_t^e=u_t+\alpha_tv_t.
$$

帽号表示规范化的比较向量。这里4个时间项访问 $t,t-3,t-6,t-9$，不要与自注意力Q/K/V的3个连续 taps 混在一起。

**[解释]** 查表为常见局部组合提供可训练的捷径；门控制该组合对当前状态的贡献。哈希碰撞意味着不同 n-gram 可能共享索引；两组哈希不等于完全没有碰撞。

**未公开到足以复现的点**：单看这几条式子不能重建词元化、每表确切向量分片、哈希常数及所有初始历史的边界处理。本文不编造这些值。

来源：发布页 Maths、模型配置。

<a id="section-13"></a>

## 13. 自注意力与视觉交叉注意力

![图 13：解码器自注意力和视觉交叉注意力的输入、投影与掩码](../assets/impl-13-attention.png)

### 13.1 Q/K/V 的三时刻混合

**[官方]** 与简单“只投影当前位置”的写法不同，解码器在Q/K/V上都有3 taps：

$$
q_{t,h}=\sum_{r=0}^{2}\tau^Q_{r,h}\odot W_{Q,h}x_{t-r},
$$
$$
k_{t,g}=\sum_{r=0}^{2}\tau^K_{r,g}\odot W_{K,g}x_{t-r},\quad
v_{t,g}=\sum_{r=0}^{2}\tau^V_{r,g}\odot W_{V,g}x_{t-r}.
$$

然后Q、K归一化并施加RoPE；Q/K维度48，注意力缩放为 $\sqrt{48}$，不是 $\sqrt{512}$。

$$
A_{tjh}=\mathrm{softmax}_{j\le t}\left(\widehat q_{t,h}^T\widehat k_{j,g(h)}/\sqrt{48}\right).
$$

输出带门：

$$
\mathrm{SA}(x)_t=W_O\left[\sigma(W_Gx_t)\odot
\mathrm{concat}_h\sum_{j\le t}A_{tjh}v_{j,g(h)}\right].
$$

$j\le t$ 是因果约束，不能读未来生成token。KV heads=2；本文不从总维度512擅自推导未知的Q heads数。

### 13.2 RoPE 的作用

**[官方]** 成对坐标旋转，以 $\theta$ 为基底的角频率为 $p\theta^{-2r/q}$。解码器配置 $\theta=100000$，编码器为10000。旋转不增加向量维度；它把位置信息带入Q/K内积。不同实现的坐标配对及二维图像位置规则不能仅凭“用了RoPE”就互换。

### 13.3 交叉注意力

Q来自文本状态，K/V来自固定视觉记忆 $M$：

$$
q^c_{t,h}=\mathcal N^c_q(W^c_{Q,h}x_t),\quad
k^c_{j,h}=\mathcal N^c_k(W^c_{K,h}M_j),\quad
v^c_{j,h}=W^c_{V,h}M_j.
$$

$$
A^c_{tjh}=\mathrm{softmax}_j\left((q^c_{t,h})^Tk^c_{j,h}/\sqrt{48}+M_{valid,j}\right).
$$

将加权V拼接、门控并投影得到 $\mathrm{CA}(x,M)$。图像不变时视觉K/V可以复用，不需要每生成一个词重新跑整张图像编码器。

一层内部的两次残差：

$$
u_1=u^e+\sigma(a_s)\mathcal N_s[\mathrm{SA}(\mathcal N(u^e))],
$$
$$
u_2=u_1+\sigma(a_c)\mathcal N_c[\mathrm{CA}(\mathcal N(u_1),M)].
$$

来源：发布页 Maths。

<a id="section-14"></a>

## 14. Hadamard MLP：与 HConvGLU 不同的结构化通道映射

![图 14：Kronecker 因子形成 512 维隐式映射](../assets/impl-14-hmlp.png)

**[官方]** 解码器用学习到的 Kronecker 因子，不等于编码器固定 Walsh + 带状权重。

$$
M_s=(A_s\otimes B_s)^T,\quad A_s\in\mathbb R^{16\times16},\ B_s\in\mathbb R^{32\times32}.
$$

Kronecker积的结果是512×512，但由 $16^2+32^2=1280$ 个因子参数确定，远小于任意512×512矩阵的262144项；这种压缩也限制映射族。

**[官方]** 输入相关通道门：

$$
c(x)=\mathbf1+U^T\mathrm{softmax}(V^Tx),
\quad V\in\mathbb R^{512\times8},\ U\in\mathbb R^{8\times512}.
$$

softmax得到8维混合权重，经 $U^T$ 返回512维。它不是8个独立的整模型专家。

$$
z_1=\Pi_1M_1D_1x,
$$
$$
z_2=\Pi_2M_2\mathrm{SiLU}(D_2c(x)\odot z_1+b),
$$
$$
\mathrm{HMLP}(x)=D_4M_3D_3z_2.
$$

$D_i$ 表示逐通道缩放，$\Pi_i$ 为置换。层内部函数结束于

$$
f_\ell(u)=u_2+\mathrm{HMLP}(\mathcal N(u_2)).
$$

**[边界]** 因子初始化、置换索引、量化分组等仍需完整实现和权重。知道数学结构，不代表可以仅凭配置直接从零写出字节兼容加载器。

来源：发布页 Maths。

<a id="section-15"></a>

## 15. 四条 mHC lanes：读出、计算、路由、写回

![图 15：四条 mHC 通路读出、路由与写回](../assets/impl-15-mhc.png)

每位置状态不是单个512向量，而是 $X_t\in\mathbb R^{4\times512}$。

### 15.1 从四路读取

**[官方]**

$$
\widehat x_t=\mathrm{RMS}(\mathrm{vec}(X_t)),\quad
 a_t=\sigma(\eta_a\Phi_a\widehat x_t+b_a),
$$
$$
u_t=X_t^Ta_t\in\mathbb R^{512}.
$$

读权重 $a_t$ 是4维。sigmoid不保证四项和为1；这不是强制概率加权平均。

### 15.2 求增量并分配写回

$$
\Delta_t=f_\ell(u_t)-u_t,
$$
$$
b_t=2\sigma(\eta_b\Phi_b\widehat x_t+\beta_b).
$$

用减去输入的方式得到该层新增的内容，而不是把原输入当成增量再重复添加。

### 15.3 Sinkhorn 路由

将动态logits重排成4×4；在log域交替行、列归一化20轮：

$$
\widetilde L_{ij}=L_{ij}-\log\sum_c e^{L_{ic}},
$$
$$
L'_{ij}=\widetilde L_{ij}-\log\sum_r e^{\widetilde L_{rj}},\quad R=e^{L^{(20)}}.
$$

于是 $R\mathbf1\approx\mathbf1$、$R^T\mathbf1\approx\mathbf1$，接近双随机。有限轮次及浮点运算所以写“约等于”。最后

$$
X_t^+=R_tX_t+b_t\Delta_t^T.
$$

第一项混合旧lanes，第二项把本层新内容按4个写入强度注入。尺寸检查：4×4乘4×512，加4×1乘1×512，结果仍4×512。

**[解释]** 这是一种模型内部信息流管理，不是同时调四个模型投票；也不是保证语义正确的验证器。

来源：发布页 Maths。

<a id="section-16"></a>

## 16. 共享原型实例分割

![图 16a：D 和 S4 两路在 128 网格融合得到 U](../assets/18_mask_fusion.png)

![图 16b：共享原型与对象系数点积得到单个像素](../assets/impl-16-prototype.png)

### 16.1 两条分支

**[官方]**

$$
U=V_{128}\odot[\uparrow_2(D)+W_eS_4],\quad W_e\in\mathbb R^{128\times64},
$$
$$
P=f_P(U)\in\mathbb R^{128\times128\times32},\quad
C=f_C(D)\in\mathbb R^{64\times64\times32}.
$$

$P$ 是32张共享的、可正可负的原型图；$C$ 是每个检测网格位置的32维系数。两支结构相似，权重各自独立。

每支两次残差块：

$$
Y^{i+1}=V\odot\{Y^i+W_i\mathrm{DW}_{3\times3,i}[\mathrm{SiLU}(\mathcal N_i(Y^i))]\},
\quad i=0,1,
$$

最后 $W_{out}\mathrm{SiLU}(\mathcal N_{out}(Y^2))$ 投影到32通道。最后投影无偏置、无输出激活，不能提前把原型截成0–1。

### 16.2 每个对象得到自己的掩码

$$
a_k=C[c(k)],\quad \ell_k(p)=\sum_{r=1}^{32}a_{kr}P_{pr},
$$
$$
m_k(p)=\mathbf1[p\in\Omega(b_k)]\sigma(\ell_k(p)).
$$

$c(k)$ 是对象中心格，$\Omega(b_k)$ 是框支持区域。极小框也保留中心格，避免没有网格中心落在框内而掩码完全无法出现。

**[原创算例]** 两个原型在某像素取值 $(1,-0.5)$，系数 $(2,1)$，则 logit=1.5，sigmoid约0.818；系数改成 $(-1,1)$，logit=−1.5，概率约0.182。共享同一套原型，换系数就能选出不同空间区域。实际有32项，不是2项。

### 16.3 为什么局部5×5足够算一个对象系数

两次3×3每次把依赖半径增加1：

$$
R=1+(3-1)+(3-1)=5.
$$

其余是逐位置操作，所以CPU可以只计算中心周围5×5×128块，保留中心输出。该结论不适用于增加了全局attention或空间归一化的改造版。

### 16.4 表达能力边界

将原型展成 $P\in\mathbb R^{16384\times32}$，把对象系数叠成 $A\in\mathbb R^{K\times32}$，则

$$
L=AP^T,\quad\mathrm{rank}(L)\le32.
$$

这是裁框和sigmoid**之前**的logit矩阵；不是“最多32个对象”，也不是最终二值掩码矩阵必然秩≤32。细杆、孔洞和极小目标会受到网格分辨率、原型和框三方面限制。

### 16.5 输出格式：本次补充核验

官方分割专题明确：

| mask_format | 几何意义 |
|---|---|
| `largest` | 最大外轮廓，文中注明为默认 |
| `polygons` | 分离的各外轮廓 |
| `merged` | 用桥连接外轮廓，桥可能跨背景 |
| `bitmap` | 原图尺寸的列优先非压缩RLE |

默认阈值0.5；轮廓使用marching squares、交点插值和简化。多边形模式不保留孔洞边界。bitmap 的 `size` 为高、宽，`counts` 从背景段开始。此为文档核验，不是本文的实机返回测试。

**重要修正**：早先API指南曾把bitmap细节标为未找到；现在已有官方直接说明，应以上表更新。RLE不是二维逐像素数组；多边形栅格化也不保证逐像素等同于bitmap，因为插值和阈值的顺序可能不同。

来源：官方实例分割专题。

<a id="section-17"></a>

## 17. 独立 OCR reader 与 CTC

![图 17：1000 像素长条的 OCR 窗口、选帧、CTC 示例](../assets/impl-17-ocr.png)

### 17.1 从原图取字，不从语义猜字

**[官方]** 文字候选框从原始RGB图裁切；等比例缩到高48，宽

$$
U=\max\{1,\mathrm{round}(48w/h)\}.
$$

CPU遵循nearest-even取整。短条补RGB127；长条用48×320窗口、步长224，重叠96。窗口数

$$
N(U)=1+\max\left(0,\left\lceil\frac{U-320}{224}\right\rceil\right).
$$

### 17.2 Reader 的空间和序列网络

```text
48×320×3 → 24×160×32 → 12×80×64
         → 6×80×128 → 3×80×384
高度平均 → 80×384 序列 → 4个序列残差块 → 字符logits
```

每个窗口像素按 $x/127.5-1$ 归一化。首个3×3 stride(2,2)卷积；后续DW+PW的stride为(2,2)、(2,1)、(2,1)。最后空间输出先应用 SiLU 再按高度求均值。横向总stride4，所以每窗80帧。

每个序列块：

$$
h=\mathrm{DW}_{1\times5}(\mathcal N(X)),\quad[v,g]=W_{up}h,
$$
$$
X^+=X+W_{down}[v\odot\mathrm{SiLU}(g)].
$$

up投影768维，拆为384+384；down回384。最后

$$
Z_t=W_{char}\mathcal N_f(X_{4,t})+b_{char},\quad q_t=\mathrm{softmax}(Z_t).
$$

字符表外的文字不会仅因结构正确就被准确读取；中文支持不能从“Unicode输出”推断。

### 17.3 感受野与重叠为何匹配

**[推导，依据公开卷积]** 递推 $r'=r+(k-1)j$、$j'=sj$，起点 $(r,j)=(1,1)$。四级横向得到(3,2)、(7,4)、(15,4)、(23,4)。四个1×5再各增16，因此

$$
r=23+4\cdot16=87,\quad j=4.
$$

一个输出帧依赖左右各43像素。半个96重叠为48，超过43，足够保留内部帧的上下文。若把序列卷积改深，旧重叠参数不一定仍足够。

### 17.4 帧选择不是先解码成字符串再拼接

第 $j$ 个窗从 $x_j=224j$ 开始。去掉内部边缘各12帧；非尾窗右界68，尾窗右界 $\lceil(U-x_j)/4\rceil$。起窗左界0，其余左界12。

**[原创算例]** $U=1000$，需5个窗，起点0、224、448、672、896。保留的全局帧范围依次是 `[0,68)`、`[68,124)`、`[124,180)`、`[180,236)`、`[236,250)`，保留68+56+56+56+14，共250帧，恰为 $\lceil1000/4\rceil$，不漏不重。

### 17.5 CTC

CTC定义字符串概率：

$$
p(s\mid I,b)=\sum_{\pi:\mathcal C(\pi)=s}\prod_tq_t(\pi_t).
$$

$\pi$ 是帧标签序列，包含blank；$\mathcal C$ 先合并连续重复，再删blank。

实际greedy路径为

$$
\widehat\pi_t=\arg\max_cq_t(c),\quad\widehat s=\mathcal C(\widehat\pi).
$$

它不保证等于对所有路径求和后概率最高的字符串。比如 `[a,a,blank,a]` 得到 `aa`，不能先删blank再合并，否则会丢掉真正重复字母。

跨窗必须合并帧后collapse，或流式保留前一帧原始label。一般 $\mathcal C(p\Vert q)\ne\mathcal C(p)\Vert\mathcal C(q)$。最后一次blank也要更新前一label状态。

### 17.6 内存与语义边界

单窗激活大小固定，但总计算随窗口数增长；文字条和累计帧输出也增长，因此“固定窗口”不是“任意长输入总内存恒定”。配置 `reads=8` 不是推理最多8行。OCR结果后合并，不回流decoder；exact-text判断请交给应用。

来源：OCR专题、结构化感知。

<a id="section-18"></a>

## 18. form 有界决策

![图 18：候选路径对数累积和有限集合内归一化](../assets/impl-18-form.png)

### 18.1 与普通描述的不同

**[官方]** form 是同一模型的另一请求模式，用用户给定字段/候选约束任务；不是“先跑OCR再回答”。它复用视觉特征，但不运行独立文字reader。

对于候选 $a$，把候选token连同字段结束符逐个计分：

$$
s(a)=\sum_{j=1}^{|\mathrm{tok}(a)+end|}
\log p(a_j\mid I,prefix,a_{<j}).
$$

再在所给候选集合 $\mathcal A$ 内归一化：

$$
P(a\mid\mathcal A,I)=\frac{e^{s(a)}}{\sum_{b\in\mathcal A}e^{s(b)}},\quad
\widehat a=\arg\max_aP(a\mid\mathcal A,I).
$$

`prefix` 包含前面已经填过的字段，字段顺序因此有意义。不要自行把求和改为平均logprob；那会改变长度效应和决策。

### 18.2 概率解释

**[原创算例]** 两个候选分数−2和−3，则首个相对概率为 $e^{-2}/(e^{-2}+e^{-3})\approx0.731$。加入第三个−2分候选后，首个降至约0.422。图像没变，仅候选集合改变，相对概率就变了。

因此它不是“现实中73.1%肯定是这个物体”的校准概率。候选词措辞、长短、先前字段会影响得分；集合里没有正确答案时仍可能选出最高项。

### 18.3 Python 使用边界

```python
import cactus
vision = cactus.Mirage(weights="./mirage.cact")
form = {
    "kind": {"enum": ["bottle", "cup", "neither"]},
    "count": {"type": "integer", "minimum": 0, "maximum": 5},
}
result = vision.extract("table.jpg", form=form)
```

这是原创建议示例，未执行。`vision.extract` 把form传入描述引擎；模块顶层的 `cactus.extract` 属于Needle文本功能，不是这个Mirage方法。

来源：结构化感知、发布页 Maths、Python wrapper。

<a id="section-19"></a>

## 19. 运行时装配与贯穿算例

![图 19：牌子、杆和文字的运行时关联原创案例](../assets/impl-19-assemble.png)

**以下为原创解释性情境，不是模型实测：** 一张照片里有一个写着“CAFE”的牌子和支撑杆。

1. stem和encoder形成图像特征，不先生成文字描述。
2. 检测器提出牌子区域、杆区域，以及牌中文字区域。此时物体区域不必已有“牌子”的名字。
3. 区域槽把中心特征、框编码、粗特征绑定到引用编号。
4. 解码器可生成“sign / pole / attached_to”这样的语义及引用。编号是区域绑定，不是跨帧永久track ID。
5. mask分支为牌子、杆选各自32维系数，共享32张原型形成轮廓。
6. OCR从原图文字框裁切，生成字符帧并collapse为`CAFE`。它可以读对，而语义描述仍误认场景；两者不是同一条概率链。
7. 运行时把对象名、框、掩码、文字与关系整合。输出JSON是结果数据结构，不是“把所有像素都经过语言token化”的证据。

### 常见错误应该归到哪一层

| 现象 | 优先检查 | 不宜直接归因 |
|---|---|---|
| 小字没有text框 | 检测、缩放、阈值、候选上限 | 一定是CTC错误 |
| 框正确但名字错 | 区域槽绑定、语义解码 | 一定是检测失败 |
| 文字少一字 | 原图crop是否截断、字符表、窗拼接 | 只调整max_tokens |
| 掩码缺细杆 | 原型细节、128网格、框支持 | 给decoder更长提示必定有效 |
| form选错 | 候选集合、措辞、视觉识别、字段依赖 | 把相对概率当校准正确率 |
| JSON有高score但关系错 | 分别评估检测与关系 | 一个score为所有字段背书 |

<a id="section-20"></a>

## 20. 初始化、量化与工程边界

![图 20：初始化权重范数与部署包体积的对照](../assets/impl-20-quant.png)

### 20.1 Gabor 是初始化，不是固定推理滤波器

**[官方]** 部分空间卷积的约一半输出滤波器用有方向的Gabor模板替换，同时保留原滤波器范数；其余保留原Gaussian初始化。模板可写为

$$
g(x,y)=\exp\left[-\frac{x'^2+\gamma^2y'^2}{2\sigma^2}\right]
\cos(2\pi f x'+\phi),
$$

其中 $(x',y')$ 是旋转后的坐标。取离散3×3样本、去均值，再与输入通道随机系数组合；若原滤波器范数为 $r$，替换为

$$
W'=r\frac{G}{\max(\|G\|_F,10^{-12})}.
$$

**[推导]** 这保留权重能量但改变方向。对输入patch $z$，响应为 $w^Tz$：同范数 $w$ 的方向变化可以令响应增大、减小甚至变号。所以“范数一样”不能证明激活分布和训练精度一样。训练后模板会改变，不能声称推理仍是固定Gabor检测器。

来源：Gabor初始化。

### 20.2 “2 bit”不是全部张量2 bit

**[官方]** 主量化矩阵以2bit为主，embedding和mHC为4bit，HConvGLU带和偏置保留FP16；CPU加载时其带可展开成FP32。公开参数总量51.3M，部署文件21.6MB。

**[推导]** 若粗暴算 $51.3\times10^6\times2/8$，只有约12.8MB，明显不能解释21.6MB文件。原因包括混合精度张量、量化参数和元数据等；文件大小也不是全部运行时内存，激活、KV cache、图像缓存、输出缓冲都另占空间。

来源：发布说明、HConvGLU实现说明、模型配置。

### 20.3 什么足够确定，什么仍不够

本文给出了大部分公开前向结构，但没有宣称能凭报告完整重训练或逐比特复现。仍需核实：完整训练数据与采样、损失权重时间表、所有哈希常数、词表/字符表、量化分组、native具体默认值、后端舍入与边界。

`seg_loss=0.0` 是一个配置字段，不能单凭它推断掩码从未训练；`training_step=1100000` 不说明训练数据规模；`dtype=float32` 与部署混合量化并不矛盾。

官网演示本地推理不等于无网络记录。此前静态核验发现演示会记录预测JSON及设置、尺寸、时序等元数据；未发现该payload含原始像素，未做实际上传测试。敏感图应在本地模型中使用，显式固定本地库和权重、关闭遥测并以网络审计确认离线。

<a id="section-21"></a>

## 21. 数学审查与来源清单

![图 21：视觉记忆、mHC 和 OCR 的维度复核](../assets/impl-21-audit.png)

### 21.1 本报告审查点

- stem五次stride2：512/32=16；16×16=256。
- 注意力阶段256图格+4register；下游空间grid不带register。
- 编码器缩放$\sqrt{32}$，解码器注意力缩放$\sqrt{48}$，Engram相似度缩放$\sqrt{512}$，三者不混用。
- HConvGLU三个带+一个gate偏置；边界zero padding；GELU门不是sigmoid。
- HMLP的16×16与32×32 Kronecker积产生512×512。
- mHC读写/路由矩阵乘法维度闭合。
- 框位置编码4×(8+8)=64；区域拼接特征128+64=192后投影至512。
- 原型为128×128×32，系数为32，不是32个固定物体。
- OCR每窗80帧；87像素感受野；224/4=56帧步长；1000像素原创算例保留250帧。
- CTC先合并连续标签再删blank；窗先拼帧再collapse。
- form评分含字段结束符；概率只在给定候选集合内归一化。

### 21.2 一手来源

1. Mirage 发布页及 Maths 面板：架构、stem/body/GQA/level memory/neck、decoder/Engram/HMLP/mHC公式和部署规模。公式与说明已写入本章，无需访问发布页。
2. 模型配置：维度、层数、头数、哈希、量化与版本字段。
3. Structured Visuo-Semantic Perception：整体分工、区域提议/引用、OCR边界及form计分。
4. HConvGLU for Channel Mixing：Walsh顺序、带状门控、参数/MAC核算和CPU缩放。
5. Instance Masks from Shared Features：两分支公式、局部5×5、掩码几何与RLE格式。
6. CTC Decoding Across Image Windows：reader尺寸、窗口保留帧、感受野和collapse边界。
7. Gabor Initialisation：滤波器模板、范数保持与训练限制。
8. Python Mirage wrapper：输入与describe/extract接口边界，不足以独立证明所有native内部默认值。

> **离线使用**：本文已解释必要的变量、尺寸和推导，不依赖点开链接才能读懂。来源与版本名称用于核验，不需要跳转到外部页面。Markdown 数学采用 LaTeX 定界符；不支持数学渲染的阅读器仍可读公式源码，可改读随包的离线 HTML。

[返回项目目录](../README.md)
