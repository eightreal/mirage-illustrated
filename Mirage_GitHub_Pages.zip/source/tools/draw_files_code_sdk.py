"""生成本项目的文件／代码／SDK 示意图（SVG）；可用 Inkscape 导出 PNG。"""
from pathlib import Path
from html import escape
import subprocess
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'assets'
BLUE='#366eaa'; TEAL='#197e70'; AMBER='#ad5f17'; PURPLE='#6c5097'; INK='#182a42'
PALE={BLUE:'#eaf4ff',TEAL:'#e5f6ef',AMBER:'#fff0dc',PURPLE:'#f2ebff',INK:'#e9eef6'}

class Diagram:
    def __init__(self,title,subtitle,w=1000,h=355):
        self.w=w
        self.h=h
        self.parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">', '<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#60748c"/></marker></defs>']
        self.rect(0,0,w,h,'#f4f8fc')
        self.text(38,49,title,33,bold=True)
        self.text(40,81,subtitle,17)
    def rect(self,x,y,w,h,fill,stroke='none',r=0):
        self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="2"/>')
    def text(self,x,y,s,size=20,color=INK,anchor='start',bold=False):
        self.parts.append(f'<text x="{x}" y="{y}" fill="{color}" font-family="Noto Sans CJK SC, sans-serif" font-size="{size}" font-weight="{700 if bold else 400}" text-anchor="{anchor}">{escape(s)}</text>')
    def arrow(self,x1,y1,x2,y2):
        self.parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#60748c" stroke-width="2.3" marker-end="url(#arrow)"/>')
    def line(self,x1,y1,x2,y2,color='#60748c'):
        self.parts.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color}" stroke-width="2"/>')
    def card(self,x,y,w,h,name,desc='',color=BLUE):
        self.rect(x,y,w,h,PALE[color],color,10)
        self.text(x+w/2,y+(31 if desc else h/2+7),name,21,color,'middle',True)
        if desc: self.text(x+w/2,y+63,desc,17,INK,'middle')
    def cells(self,x,y,rows,cols,s,color,filled=None,labels=None):
        for i in range(rows):
            for j in range(cols):
                self.rect(x+j*s,y+i*s,s-3,s-3,color if filled and (i,j) in filled else PALE[color],color,3)
                if labels:
                    self.text(x+j*s+(s-3)/2,y+i*s+s*.65,labels[i][j],min(20,s*.39),INK,'middle',True)
    def footer(self,s):
        self.text(40,self.h-26,s,17)
    def save(self,name):
        self.parts.append('</svg>')
        f=ASSETS/(name+'.svg')
        f.write_text('\n'.join(self.parts),encoding='utf-8')
        return name

figures=[]
def add(d,name):figures.append(d.save(name))

d=Diagram('配置、权重与运行库的分工','部署时，真正读取 .cact 并运算的是平台运行库。')
d.card(42,115,240,76,'config.json','尺寸、发布配置',BLUE)
d.card(42,208,240,76,'mirage.safetensors','浮点权重，研究检查',PURPLE)
d.card(347,161,240,76,'mirage.cact','部署权重档案',TEAL)
d.arrow(590,198,665,198)
d.card(675,161,278,76,'libcactus','加载档案并执行推理',AMBER)
d.footer('左侧是可供检查的资料，不代表官方 SDK 每次部署时也读取这两份文件。')
add(d,'files-roles')

d=Diagram('safetensors 字节剖面','文件按 little-endian uint64 读取 JSON 头长；图不按长度比例。',h=316)
for x,w,lab,sub,cl in [(42,206,'8 B','uint64 头长 55,280',BLUE),(248,286,'55,280 B','JSON：583 个张量条目',PURPLE),(534,425,'216,315,216 B','浮点数据区',TEAL)]:
    d.rect(x,136,w,70,PALE[cl],cl,6); d.text(x+w/2,164,lab,22,cl,'middle',True);d.text(x+w/2,191,sub,17,INK,'middle')
for x,lab in [(42,'0'),(248,'8'),(534,'55,288'),(956,'216,370,504（文件末尾）')]:
    d.text(x,115,lab,17,anchor='end' if x==956 else 'start')
d.footer('data_offsets 以数据区起点为零；不能把这张图用于 .cact 的内部布局。')
add(d,'files-header')

d=Diagram('从张量矩阵读尺寸','只画几行几列帮助读维度；展示的是形状，不是公开的权重值。')
for x,title,sub,cl,col,row in [(70,'gate_conv','512 × 65',BLUE,5,4),(375,'slot_proj','192 × 512',TEAL,8,3),(735,'reader/out','384 × 307',PURPLE,5,4)]:
    d.text(x,123,title,21,cl,bold=True);d.cells(x,141,row,col,24,cl); d.text(x,258,sub,20,cl,bold=True)
d.footer('307 = 306 个字符 + 1 个 CTC blank；192 = 128 维中心特征 + 64 维位置编码。')
add(d,'files-tensors')

d=Diagram('同一个 51.3M 数字的两种口径','下面是浮点文件实测总数到发布数字的一种算术解释，不是部署裁剪证明。',h=337)
d.rect(45,142,850,45,PALE[TEAL],TEAL,4); d.rect(850,142,40,45,PALE[AMBER],AMBER); d.rect(890,142,5,45,PALE[PURPLE],PURPLE);d.text(48,126,'浮点文件：54,078,804 个标量',20,bold=True)
d.text(52,171,'剩余 51,256,946 ≈ 51.3M',21,TEAL,bold=True)
d.line(870,190,870,221,AMBER); d.line(870,221,540,221,AMBER)
d.text(112,228,'候选扣减：MTP 相关 2,559,714',19,AMBER)
d.line(894,190,894,258,PURPLE); d.line(894,258,540,258,PURPLE)
d.text(112,265,'候选扣减：name_head 262,144',19,PURPLE)
d.footer('未读取 .cact 内部目录，不能由算术推断部署中缺失的张量。')
add(d,'files-counts')

d=Diagram('为什么不能把 22 MB 除以 2 bit','横条同尺度；上条是理论裸权重，下条是实际磁盘文件。',h=328)
for y,label,b,cl in [(140,'全参数 2-bit 的假设值',12.825,BLUE),(217,'实际 .cact 文件',21.611043,TEAL)]:
    d.text(45,y,label,21,bold=True);d.rect(325,y-24,b*24,35,PALE[cl],cl,4);d.text(337,y+1,f'{b} MB',19,cl,bold=True)
d.footer('发布说明：部分参数使用 4-bit 或 FP16。部署档案的逐项分摊未核实。')
add(d,'files-bits')

d=Diagram('谁随当前图片或生成请求改变？','把常被叫作 memory 的内容按来源区分。',h=355)
groups=[
 (45,'每张图片',TEAL,[('网格 E','按位置读整图'),('区域 slot','按框读局部')]),
 (365,'每个解码请求',BLUE,[('KV cache','复用历史序列计算'),('RAM 工作区','物理内存，生命周期依实现')]),
 (685,'发布时固定',PURPLE,[('Engram 参数表','作为模型权重加载')])]
for x,heading,cl,items in groups:
    d.text(x,123,heading,20,cl,bold=True)
    for i,(n,sub) in enumerate(items):d.card(x,144+i*79,268,71,n,sub,cl)
d.footer('这五类都不能直接等同于聊天历史；持久保存须由应用另做。')
add(d,'files-memory-types')

d=Diagram('区域 slot 的两条投影支路','方框内是向量尺寸；512 + 512 表示同维相加，而不是拼成 1024。',h=368)
for x,y,w,label,sub,cl in [(42,113,205,'细特征 128','D 中心取样',TEAL),(42,200,205,'位置编码 64','框的四个坐标',AMBER),(42,280,205,'均值特征 512','在 E 内汇聚',BLUE),(330,157,205,'拼接 192','乘 192×512',TEAL),(330,280,205,'均值 512','乘 512×512',BLUE),(626,212,143,'相加 → RMS','再加引用向量',PURPLE),(805,212,148,'区域 slot','512 维',PURPLE)]:
    d.card(x,y,w,69,label,sub,cl)
for a in [(251,148,323,180),(251,236,323,205),(251,312,323,312),(540,191,619,232),(540,310,619,262),(774,246,797,246)]:d.arrow(*a)
add(d,'files-slot')

d=Diagram('把一个区域 slot 缩成 2 维手算','RMS gain=1、ε=0；数字是教学数据，与真实激活无关。')
for x,y,w,lab,sub,cl in [(43,122,166,'[3, 4]','中心+位置投影',TEAL),(43,222,166,'[1, 2]','平均池化投影',BLUE),(260,172,135,'[4, 6]','相加',TEAL),(447,172,190,'[.7845, 1.1767]','除以 √26',BLUE),(690,172,266,'[.9259, 1.0353]','加 √2 × [.1, −.1]',PURPLE)]:
    d.card(x,y,w,74,lab,sub,cl)
for a in [(215,158,252,193),(215,254,252,220),(401,209,440,209),(644,209,681,209)]:d.arrow(*a)
d.footer('最后一项是区域编号的引用向量，不是第三条图像特征。')
add(d,'files-slot-values')

d=Diagram('注意力读图：从打分到加权向量','教学简化：q=[1,1]，K 和 V 投影为恒等。')
for y,v,score,p,cl in [(126,'[1, 0]','0.7071',.33024,BLUE),(219,'[0, 2]','1.4142',.66976,TEAL)]:
    d.card(45,y,152,74,v,'memory 向量',cl);d.arrow(206,y+37,252,y+37)
    d.card(262,y,155,74,score,'点积 / √2',cl); d.arrow(425,y+37,470,y+37)
    d.rect(480,y+18,205*p,36,PALE[cl],cl,4);d.text(702,y+44,f'{p:.5f}',19,cl)
    d.arrow(779,y+37,805,211)
d.card(812,163,157,74,'[.33, 1.34]','加权输出',PURPLE)
d.footer('softmax 归一化的是两条打分；输出是两个 V 的加权和。')
add(d,'files-attention')

d=Diagram('Engram 表的 18,432 是行容量','固定的模型参数表；只画 5 行，不代表真实的哈希函数。')
for i in range(3):
    d.cells(326+110*i,136+8*i,5,4,19,PURPLE,{(2,1),(2,2),(2,3)} if i==0 else None)
d.card(45,150,211,74,'当前 token 组合','示例：相邻 2 或 3 个',BLUE)
d.arrow(261,188,319,188)
d.text(329,278,'若干分组，每组 18,432 行；每行 128 维',19,PURPLE,bold=True)
d.card(710,153,247,74,'与图像槽位不同','不受检测框数量控制',TEAL)
d.footer('实际头部有两张 [4, 18432, 128] 参数表；前导 4 的具体接线不能靠 shape 反推。')
add(d,'files-engram')

d=Diagram('空间网格与临时寄存器的边界','网格缩画成 4×4，真实是 16×16；寄存器不是检测框，也不是额外像素。')
d.cells(45,128,4,4,29,BLUE,{(1,1),(1,2),(2,1)})
d.cells(168,128,4,1,29,AMBER,{(0,0),(1,0),(2,0),(3,0)})
d.text(40,267,'空间位置 + 4 个 register',17)
d.arrow(213,186,343,186)
d.card(353,145,232,'注意力 + level memory','保留网格位置数',TEAL)
d.arrow(592,186,703,186)
d.cells(713,128,4,4,29,BLUE,{(1,1),(1,2),(2,1)})
d.text(707,267,'E 网格送给下游',17)
d.footer('上图没有把每图有多少区域 slot 固定为某个数字。')
add(d,'files-token-boundary')

d=Diagram('三个预算绝不能互推','用同一条路径的三个对象对照；形状决定某些算术，实测性能还依赖后端。')
for x,lab,sub,cl,a,b in [(43,'参数数量','权重元素',PURPLE,3,9),(365,'计算量','用权重计算多少次',BLUE,4,6),(687,'运行内存','同时存活的数据与工作区',TEAL,5,5)]:
    d.card(x,119,268,70,lab,sub,cl);d.cells(x+19,212,a,b,18,cl,{(0,0),(1,1)})
d.footer('参数元素数 → 乘位宽可算裸存储；不能直接算出峰值内存、时延或吞吐。')
add(d,'files-budgets')

d=Diagram('带状权重不存整张稠密矩阵','下图缩到 9 个通道、半宽 1；真实用 512 个通道、半宽 32。',h=380)
d.text(47,123,'稠密：每个输入都直接连每个输出',18)
d.cells(47,143,9,9,20,PURPLE,{(i,j) for i in range(9) for j in range(9)})
d.text(358,123,'带状：只取 Walsh 空间的邻域',18)
d.cells(358,143,9,9,20,BLUE,{(i,j) for i in range(9) for j in range(9) if abs(i-j)<=1})
d.card(649,167,301,78,'每条实际权重 512×65','跳过越界时 32,224 个有效项',TEAL)
d.footer('横轴输入通道，纵轴输出通道；边缘一行比中间行少有效邻居。')
add(d,'files-band')

d=Diagram('一个 slot 的乘加预算','每条支路在矩阵的每列做一次内积；两个 512 维结果再相加。')
for y,n,k,op,cl in [(128,'输入 192','192×512','98,304 MAC',TEAL),(219,'输入 512','512×512','262,144 MAC',BLUE)]:
    for x,w,t,s in [(44,174,n,'向量'),(267,193,k,'权重矩阵'),(517,208,op,'乘加项')]:
        d.card(x,y,w,73,t,s,cl)
    d.arrow(226,y+36,259,y+36);d.arrow(468,y+36,507,y+36)
d.arrow(731,164,778,200);d.arrow(731,255,778,224)
d.card(786,176,168,73,'360,448','合计 / slot',PURPLE)
d.footer('不含池化、坐标编码、两个分支的加和及 RMS。')
add(d,'files-slot-budget')

d=Diagram('共享原型如何得到一个像素的 mask','一张原型图每个像素有 32 个值；这里缩为 3 个通道。')
d.card(45,120,240,73,'[1, −2, .5]','该像素的共享原型 P',BLUE)
d.card(45,214,240,73,'[.8, −.2, 1]','某个框对应的系数 C',TEAL)
d.arrow(292,157,380,192);d.arrow(292,251,380,219)
d.card(388,169,220,73,'0.8 + 0.4 + 0.5','内积 logit = 1.7',PURPLE)
d.arrow(617,205,676,205);d.card(688,169,259,73,'0.8455','sigmoid 后的概率',AMBER)
d.footer('换框只替换 C，同一张 P 继续共用；所有像素各自做一次内积。')
add(d,'files-mask-budget')

d=Diagram('K 和 V 缓存按什么轴展开？','示意：每层每个 token 中，K 和 V 都保留两个 KV heads 的向量。')
for y,name,a,b,cl in [(134,'KV head 0',48,64,BLUE),(218,'KV head 1',48,64,TEAL)]:
    d.text(45,y+26,name,21,bold=True)
    d.rect(217,y,a*4,47,PALE[cl],cl,6);d.rect(217+a*4,y,b*4,47,PALE[PURPLE],PURPLE,6)
    d.text(310,y+30,'K：48 维',20,cl,'middle');d.text(533,y+30,'V：64 维',20,PURPLE,'middle')
d.card(710,172,240,73,'8 × 1024 × 2','层 × token × 字节',AMBER)
d.footer('教学估算 3.5 MiB；未计卷积状态、跨注意力以及分配器等。')
add(d,'files-cache')

d=Diagram('OCR 长行：保留帧交给 CTC','宽 1200 的教学条带；五窗重叠 96 像素。橙色为重叠中丢弃的内部边界。',h=475)
for i,start in enumerate([0,224,448,672,896]):
    x=50+start*.68; y=117+i*45; ww=min(320,1200-start)*.68
    d.rect(x,y,ww,29,PALE[TEAL],TEAL,4)
    if i>0:d.rect(x,y,48*.68,29,PALE[AMBER],AMBER,3)
    if i<4:d.rect(x+ww-48*.68,y,48*.68,29,PALE[AMBER],AMBER,3)
    d.text(x+34,y+21,f'{start} 起 / {[68,56,56,56,64][i]} 帧',15)
d.text(46,374,'CTC 示例',20,bold=True)
d.cells(200,343,1,9,46,BLUE,{(0,i) for i in [0,3,6,7]},[['b','b','∅','o','o','∅','o','k','k']])
d.arrow(627,367,710,367);d.card(722,340,224,60,'book',color=TEAL)
d.footer('先合并连续重复，再删 blank ∅，才能保留中间被 blank 分开的两个 o。')
add(d,'files-ocr')

d=Diagram('这个包里哪些是真资料，哪些是教学值？','先看左列文件类型，再看可用于哪一项验证。')
for y,n,s,cl in [(112,'官方配置/张量头部','查真实名字、形状、数据区大小',TEAL),(193,'toy_model.npz','手算投影后加法、RMS 与查图加权',BLUE),(274,'Markdown / SVG','阅读步骤与机制，不是激活转储',PURPLE)]:
    d.card(46,y,255,60,n,color=cl);d.arrow(309,y+30,378,y+30);d.card(388,y,558,60,s,color=cl)
add(d,'files-package')

d=Diagram('教学代码确实在 D 上训练什么？','小色块只有一个正例格；冻结 Stem、Body、Attention、FPN 的随机权重。',h=377)
d.cells(47,130,6,6,24,AMBER,{(2,3)})
d.text(47,306,'合成图片 / 示意格',18)
d.arrow(204,204,253,204)
d.card(264,169,237,74,'固定编码与融合','生成 D 特征',TEAL)
d.arrow(511,204,561,204)
d.card(573,169,198,74,'线性热图头','只更新 w、b',BLUE)
d.arrow(780,204,815,204)
d.cells(825,134,5,5,23,PURPLE,{(2,3),(2,2),(3,3)})
d.text(813,283,'预测概率格',17)
d.footer('合成标签用于算加权 BCE；验证下降不等同于真实图片检测准确。')
add(d,'code-toy-training')

d=Diagram('真实调用的边界：本地图片、本地进程','两个调用入口归到同一 ABI；示例本身不会随包提供运行二进制或权重。',h=384)
d.card(42,126,224,73,'Python SDK','Mirage.describe / extract',BLUE)
d.card(42,228,224,73,'ctypes 示例','先解码成 RGB',PURPLE)
d.arrow(274,162,370,190);d.arrow(274,265,370,225)
d.card(379,173,206,73,'cactus_* ABI','load / describe',AMBER)
d.arrow(591,201,675,177);d.arrow(591,225,675,267)
d.card(687,141,270,73,'原生引擎 + .cact','执行真正的模型',TEAL)
d.card(687,228,270,73,'测试替身','只核对参数与输出契约',PURPLE)
d.footer('已做替身测试；官方运行库、权重、设备性能没有在本环境实测。')
add(d,'code-native-boundary')

d=Diagram('官方源码快照与部署文件的区别','源码供核对 Python wrapper 和 C ABI，不是装好后可直接识别的离线安装包。')
for x,name,sub,cl in [(46,'源码快照','bb822a3，Python 项目 4.2.0',BLUE),(364,'原生运行库','构建或取得平台适配二进制',TEAL),(682,'部署权重','另外取得 mirage.cact',AMBER)]:
    d.card(x,130,270,78,name,sub,cl)
d.text(47,249,'包内',22,BLUE,bold=True);d.text(366,249,'包外',22,TEAL,bold=True);d.text(683,249,'包外',22,AMBER,bold=True)
d.footer('源码里其他模型的训练和转换脚本不能替代 Mirage 官方训练管线。')
add(d,'sdk-package')

def export(name):
    subprocess.run(['inkscape',str(ASSETS/(name+'.svg')),'--export-width=1300',
                    '--export-filename='+str(ASSETS/(name+'.png'))],
                   check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=4) as ex:list(ex.map(export,figures))
