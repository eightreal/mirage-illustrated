"""Check packaged navigation, PNG/SVG paths and absence of network dependencies in rendered pages."""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

class Links(HTMLParser):
    def __init__(self):
        super().__init__(); self.refs=[]
    def handle_starttag(self,tag,attrs):
        for name,val in attrs:
            if name in ('src','href') and val and tag in ('img','a','link','script','iframe'):
                self.refs.append(val)

root=Path(__file__).resolve().parents[1]
pages=sorted(root.rglob('*.html'))
missing=[]
for page in pages:
    parser=Links(); parser.feed(page.read_text(encoding='utf-8'))
    for ref in parser.refs:
        r=urlsplit(ref)
        if r.scheme or r.netloc or (r.path and not (page.parent/unquote(r.path)).is_file()):
            missing.append((page.relative_to(root),ref))
assert not missing,missing
assert (root/'docs/02-implementation.html').read_text(encoding='utf-8').count('<math') > 40
assert (root/'upstream/cactus-sdk-bb822a3.tar.gz').is_file()
print(f'PASS: {len(pages)} HTML pages / local links and images / MathML / SDK archive')
