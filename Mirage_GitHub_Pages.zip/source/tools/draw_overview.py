"""Generate the README PNGs. Requires Pillow and Noto Sans CJK SC."""
from pathlib import Path
import math
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
N = Path('/usr/share/fonts/opentype/noto')
INK, SUB, BLUE, TEAL, AMBER, BG = '#153047','#4a6176','#2763a1','#007e81','#a46014','#f7fbff'

def fonts(size, bold=False):
    return ImageFont.truetype(str(N / ('NotoSansCJK-Bold.ttc' if bold else 'NotoSansCJK-Regular.ttc')), size, index=2)

def label(d, x,y, s, sz=24,c=INK,b=False, anchor='la'):
    d.text((x,y),s,font=fonts(sz,b),fill=c,anchor=anchor)

def canvas(w,h,title,sub):
    im=Image.new('RGB',(w,h),BG); d=ImageDraw.Draw(im)
    d.rounded_rectangle((2,2,w-3,h-3),24,outline='#d8e5ef',width=2)
    d.rounded_rectangle((30,30,39,100),4,fill=BLUE)
    label(d,56,21,title,38,b=True)
    label(d,56,74,sub,22,c=SUB)
    return im,d

def arrow(d,x,y,X,Y,c=BLUE,width=5):
    if x!=X and y!=Y:
        raise ValueError('draw one axis at a time')
    d.line((x,y,X,Y),fill=c,width=width)
    a=math.atan2(Y-y,X-x); dx,dy=math.cos(a),math.sin(a); u,v=-dy,dx
    d.polygon([(X,Y),(X-15*dx+7*u,Y-15*dy+7*v),(X-15*dx-7*u,Y-15*dy-7*v)],fill=c)

def feature(d,x,y,k,cm,accent,offset=5):
    side=k*cm
    d.rounded_rectangle((x+offset,y-offset,x+side+offset,y+side-offset),4,fill=accent)
    d.rectangle((x,y,x+side,y+side),fill='white',outline=accent,width=2)
    for i in range(k):
        for j in range(k):
            d.rectangle((x+i*cm+1,y+j*cm+1,x+(i+1)*cm-1,y+(j+1)*cm-1),
                        fill=accent if (i+2*j)%6==0 else ('#d2e7f8' if accent==BLUE else '#cbeee9'))

def net(d,x,y,w,h,name,desc):
    d.rounded_rectangle((x,y,x+w,y+h),15,fill='#e7effa',outline=BLUE,width=2)
    for i in range(5):
        d.rounded_rectangle((x+24+17*i,y+19,x+35+17*i,y+39),3,fill=BLUE)
    label(d,x+18,y+52,name,27,b=True)
    label(d,x+18,y+96,desc,16,c=SUB)

im,d=canvas(920,377,'同一个编码器，两种空间尺度','蓝框是网络模块；网格块是张量，不是另一套网络')
net(d,32,133,196,141,'共享编码器','Stem → Body → Attn')
arrow(d,234,204,274,204)
feature(d,287,158,4,22,BLUE)
label(d,332,263,'E · 16×16×512',22,b=True,anchor='ma')
arrow(d,390,204,433,204)
net(d,442,133,165,141,'Neck','投影 · 上采样 · 相加')
arrow(d,612,204,657,204)
feature(d,670,158,8,11,TEAL)
label(d,714,263,'D · 64×64×128',22,b=True,anchor='ma')
label(d,807,175,'→ 检测',21,b=True)
label(d,807,210,'→ 掩码',21,b=True)
label(d,807,245,'→ 区域槽',21,b=True)
d.line((525,323,525,287),fill=TEAL,width=4); arrow(d,525,323,525,278,TEAL)
label(d,525,336,'S16 和 S8 从 Stem 侧路输入',22,c=TEAL,b=True,anchor='ma')
im.save(ROOT/'assets'/'overview-encoder.png',optimize=True)

im,d=canvas(920,369,'三个交付物，三种核验','勾选表示这项材料能用来核查，不表示已运行官方模型')
for x,name in [(405,'接口与版本'),(593,'计算机制'),(782,'真实张量形状')]:
    label(d,x,140,name,24,b=True,anchor='ma')
for i,(name,checks,fill) in enumerate([
      ('官方 SDK 快照',(1,0,0),'#e5effa'),('独立参考代码',(0,1,0),'#def3ef'),
      ('公开模型元数据',(0,0,1),'#fbeedc')]):
    y=179+i*55
    d.rounded_rectangle((35,y,881,y+46),8,fill=fill)
    label(d,54,y+4,name,24,b=True)
    for x,mark in zip((405,593,782),checks):
        if mark:
            d.ellipse((x-16,y+8,x+16,y+40),fill=TEAL)
            d.line((x-8,y+23,x-2,y+30,x+9,y+17),fill='white',width=4,joint='curve')
        else:
            d.line((x-6,y+24,x+6,y+24),fill='#4f6070',width=3)
label(d,36,342,'实测范围：教学计算与接口契约；非官方引擎／权重精度或性能。',20,c=SUB,anchor='ls')
im.save(ROOT/'assets'/'overview-evidence.png',optimize=True)
