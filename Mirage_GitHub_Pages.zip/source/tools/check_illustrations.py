"""Check GitHub/Markdown image coverage and that the same figures are in offline HTML."""
import re
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
CHAPTERS = {
    '01-architecture.md': 1,
    '02-implementation.md': 21,
    '03-training.md': 9,
    '04-api.md': 12,
    '05-model-files.md': 6,
}
FIG = re.compile(r'!\[(?P<alt>[^\]\n]+)\]\((?P<png>[^()\n]+\.png)\)')
LINK = re.compile(r'!?\[[^\]\n]+\]\(([^()\s]+)\)')
FENCE = re.compile(r'^\s*([~\x60]{3,})')
NUM = re.compile(r'^##\s+(\d+)[.、]\s+')

class Page(HTMLParser):
    def __init__(self, path):
        super().__init__()
        self.images = []
        self.anchors = set()
        self.hrefs = []
        self.feed(path.read_text(encoding='utf-8'))
    def handle_starttag(self, tag, attrs):
        attr = dict(attrs)
        if attr.get('id'): self.anchors.add(attr['id'])
        if attr.get('name'): self.anchors.add(attr['name'])
        if tag == 'img' and attr.get('src'): self.images.append(attr['src'])
        if tag == 'a' and attr.get('href'): self.hrefs.append(attr['href'])

def prose(path):
    active = None
    for line in path.read_text(encoding='utf-8').splitlines():
        mark = FENCE.match(line)
        if mark:
            if active is None:
                active = mark[1][0]
            elif mark[1][0] == active:
                active = None
        elif active is None:
            yield line

def check(path, required=None):
    body = '\n'.join(prose(path))
    figs = list(FIG.finditer(body))
    for m in LINK.finditer(body):
        url = urlsplit(m[1])
        assert not (url.scheme or url.netloc), (path, m[1], 'external dependency')
        if url.path:
            assert (path.parent / unquote(url.path)).exists(), (path,m[1],'bad link')
    page = Page(ROOT/'打开这里.html' if path == ROOT/'README.md' else path.with_suffix('.html'))
    for href in page.hrefs:
        u = urlsplit(href)
        if not u.path and u.fragment:
            assert unquote(u.fragment) in page.anchors, (path, href, 'missing jump target')
    assert figs and {m['png'] for m in figs} <= set(page.images), (path, 'missing offline figure')
    if required:
        seen = {}
        current = None
        for line in body.splitlines():
            if line.startswith('## '):
                match = NUM.match(line)
                current = int(match[1]) if match else None
                if current is not None: seen[current] = 0
            elif current is not None and FIG.search(line):
                seen[current] += 1
        if required > 1:
            assert list(seen) == list(range(1,required+1)), (path, seen)
            assert all(seen.values()), (path, seen)
    return {str((path.parent / m['png']).resolve()) for m in figs}

asset_paths = set()
for name, required in CHAPTERS.items():
    asset_paths.update(check(ROOT/'docs'/name, required))
for name in ['README.md', 'code/README.md', 'upstream/README.md']:
    asset_paths.update(check(ROOT/name))
for p in asset_paths:
    assert Path(p).read_bytes().startswith(b'\x89PNG\r\n\x1a\n'), (p,'not PNG')
print(f'PASS: 5 chapters, 48 numbered sections, project index + code/SDK notes; {len(asset_paths)} linked PNG illustrations; same assets in offline HTML.')
