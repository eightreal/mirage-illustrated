"""Make offline figures tappable without JavaScript or an internet connection."""
from pathlib import Path
import re
import sys

IMG = re.compile(r'<img\b[^>]*\bsrc="([^"]+\.png)"[^>]*>', re.S)
p = Path(sys.argv[1])
def full_size(m):
    src = m.group(1)
    return f'<a class="figure-zoom" href="{src}" title="打开原尺寸图片">{m.group(0)}</a>'
s = p.read_text(encoding='utf-8')
p.write_text(IMG.sub(full_size, s), encoding='utf-8')
