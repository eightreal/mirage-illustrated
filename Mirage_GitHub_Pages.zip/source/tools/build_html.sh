#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
render() {
  pandoc --from=markdown+tex_math_single_backslash --to=html5 --standalone --mathml --metadata=lang:zh-CN -M title="$3" -H tools/offline_style.html "$1" -o "$2"
  python3 tools/link_fullsize_images.py "$2"
}
rendered_source() {
  # Markdown remains the editable source and links to its sibling .md.
  # HTML output rewrites local chapter/index links, including each return link.
  sed -E 's/\]\(([^# )]+)\.md\)/](\1.html)/g' "$1" | sed 's@](\.\./README.html)@](../打开这里.html)@g' > "$2"
}
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT HUP INT TERM
rendered_source README.md "$tmp/readme.md"
render "$tmp/readme.md" "打开这里.html" "Mirage 图解技术文档项目"
for page in docs/*.md code/README.md upstream/README.md; do
  [ -f "$page" ] || continue
  title=$(head -1 "$page" | sed 's/^# //')
  printf '<p class="nav"><a href="../打开这里.html">返回项目目录</a></p>\n\n' > "$tmp/page.md"
  rendered_source "$page" "$tmp/content.md"
  tail -n +2 "$tmp/content.md" >> "$tmp/page.md"
  render "$tmp/page.md" "${page%.md}.html" "$title"
done
