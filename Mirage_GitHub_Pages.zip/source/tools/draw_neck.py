"""Generate the project-owned editable feature pyramid figure (stdlib only)."""
from pathlib import Path
from html import escape
p=Path(__file__).resolve().parents[1]/'assets'/'17_d_fusion.svg'
s=['''<svg xmlns="http://www.w3.org/2000/svg" width="1420" height="840" viewBox="0 0 1420 840">
<defs><marker id="a" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#345471"/></marker></defs>
<style>text{font-family:"Noto Sans CJK SC",sans-serif;fill:#17344c;font-size:21px}.small{font-size:18px;fill:#4d6074}.title{font-size:34px;font-weight:700}.arrow{stroke:#345471;stroke-width:3;fill:none;marker-end:url(#a)}.net{fill:#efe8f8;stroke:#9175aa;stroke-width:2}.tensor{fill:#deeffb;stroke:#709fbd;stroke-width:2}.op{fill:#fff0d4;stroke:#af8856;stroke-width:2}.panel{fill:#fff;stroke:#c5d2df;stroke-width:2}</style>
<rect width="100%" height="100%" fill="#f3f7fb"/>''']
def txt(x,y,t,css=''):
    s.append(f'<text x="{x}" y="{y}" class="{css}">{escape(t)}</text>')
def rect(x,y,w,h,css):
    s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" class="{css}"/>')
def box(x,y,w,h,css,a,b):
    if css=='tensor':
        rect(x+9,y-9,w,h,css)
    rect(x,y,w,h,css);txt(x+15,y+31,a);txt(x+15,y+60,b,'small')
def arrow(x1,y1,x2,y2):
    s.append(f'<path class="arrow" d="M{x1} {y1}L{x2} {y2}"/>')
def path(d):
    s.append(f'<path class="arrow" d="{d}"/>')
txt(35,51,'B / 两级特征金字塔：细空间特征 D 从哪里来？','title')
txt(35,88,'紫色是学习模块，蓝色是激活张量，黄色是固定运算。重复端口 T₃₂ 表示同一张量。','small')
for y,t in [(120,'第一级  ·  合并粗图 E 和 Stem 第 4 级'),(440,'第二级  ·  合并 T₃₂ 和 Stem 第 3 级')]:
    rect(25,y,1370,290,'panel');txt(45,y+42,t)
box(50,193,185,76,'tensor','E · 主干输出','16×16×512')
box(285,193,200,76,'net','点投影 W_E','512 → 128')
box(530,193,160,76,'op','上采样 ×2','32×32×128')
box(50,305,185,76,'tensor','S₁₆ · Stem F4','32×32×256')
box(285,305,200,76,'net','点投影 W₁₆','256 → 128')
box(750,193,105,76,'op','⊕','相加')
box(910,193,188,76,'net','残差块 B','DW + PW')
box(1155,193,185,76,'tensor','T₃₂ · 中间结果','32×32×128')
for a,b in [(245,280),(490,525),(695,745),(860,905),(1103,1150)]:arrow(a,231,b,231)
arrow(245,343,280,343);path('M490 343H800V275')
box(50,514,185,76,'tensor','T₃₂ · 同上','32×32×128')
box(285,514,200,76,'op','上采样 ×2','64×64×128')
box(50,625,185,76,'tensor','S₈ · Stem F3','64×64×128')
box(285,625,200,76,'net','点投影 W₈','128 → 128')
box(550,514,105,76,'op','⊕','相加')
box(710,514,363,76,'net','三个残差块 + 归一化 + SiLU','B₁ → B₂ → B₃ → Norm → SiLU')
box(1155,514,185,76,'tensor','D · 融合输出','64×64×128')
for a,b in [(245,280),(490,545),(660,705),(1078,1150)]:arrow(a,552,b,552)
arrow(245,663,280,663);path('M490 663H600V596')
txt(35,776,'D 供检测、掩码系数、掩码原型融合和区域 slot 采样。OCR 用检测框从原图裁取 RGB 像素。','small')
txt(35,807,'Stem F2 的 S₄（128×128×64）绕过本图的 Neck，进入单独的掩码原型融合。','small')
p.write_text(''.join(s)+'</svg>',encoding='utf-8')
