#!/usr/bin/env python3
"""Generate editable SVG and Markdown-ready PNG artwork (requires Inkscape)."""
from pathlib import Path
from html import escape
from subprocess import run, DEVNULL
import re
ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'assets'
N,B,G,R,M='#17324a','#245fa4','#067a65','#a03e26','#435d73'
P,T,O='#e7f1fc','#dff4eb','#fff0e2'
class F:
 def __init__(self,title,sub,h=364):
  self.h=h
  self.s=[f'<svg xmlns="http://www.w3.org/2000/svg" width="640" height="{h}" viewBox="0 0 640 {h}">','<defs><marker id="a" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="userSpaceOnUse"><path d="M0 0L9 4.5L0 9Z" fill="#435d73"/></marker></defs>']
  self.box(0,0,640,h,'#f4f8fc','none',14);self.text(28,43,title,30,N,True);self.text(28,77,sub,20,M)
 def text(self,x,y,s,size=21,c=N,b=False,align='start'):
  self.s.append(f'<text x="{x}" y="{y}" font-family="Noto Sans CJK SC, sans-serif" font-size="{size}" fill="{c}" font-weight="{700 if b else 400}" text-anchor="{align}">{escape(s)}</text>')
 def box(self,x,y,w,h,fill='white',stroke='#abc0d3',r=5):
  self.s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="2" rx="{r}"/>')
 def chip(self,x,y,w,h,t,fill=P,size=20):
  self.box(x,y,w,h,fill); self.text(x+w/2,y+h/2+size*.34,t,size,N,True,'middle')
 def line(self,x,y,u,v,arrow=False,c=M,dash=False):
  l=f'<path d="M{x} {y}L{u} {v}" stroke="{c}" stroke-width="2.6" fill="none"'
  if arrow:l+=' marker-end="url(#a)"'
  if dash:l+=' stroke-dasharray="6 5"'
  self.s.append(l+'/>')
 def dot(self,x,y,c=B,r=5):self.s.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{c}"/>')
 def poly(self,ps,c):
  self.s.append(f'<polyline points="{" ".join(f"{x},{y}" for x,y in ps)}" stroke="{c}" stroke-width="4" fill="none"/>')
 def flow(self,labels,y=125):
  w=(584-24*(len(labels)-1))/len(labels)
  for i,t in enumerate(labels):
   x=28+i*(w+24); self.chip(x,y,w,47,t,T if i==len(labels)-1 else P,19)
   if i<len(labels)-1:self.line(x+w+3,y+24,x+w+21,y+24,True)
 def rows(self,pairs,y=110):
  for i,(a,b) in enumerate(pairs):
   yy=y+52*i; self.text(29,yy+26,a,20,B,True)
   self.line(175,yy+19,209,yy+19,True)
   self.text(224,yy+26,b,20)
   self.line(29,yy+42,609,yy+42,c='#c7d6e3')
 def out(self,name):
  svg=A/(name+'.svg')
  svg.write_text('\n'.join(self.s+['</svg>'])+'\n',encoding='utf-8')
  run(['inkscape',str(svg),'--export-width=1280',f'--export-filename={svg.with_suffix(".png")}'],check=True,stdout=DEVNULL,stderr=DEVNULL)

def training():
 f=F('三种材料，各回答什么？','先核对出处，再判断结论属于事实还是设计',322)
 f.rows([('配置与权重头','核对步数、张量形状和数据类型'),('官方专题','核对 Gabor 初始化、前向机制'),('自编实验','试接线和监督，不能还原原训练')])
 f.text(29,302,'不能把三类材料拼成一份“官方完整训练配方”。',20,R); f.out('training-01-evidence')

 f=F('初始化改变方向，不改变范数','二维教学示意，圆周代表相同的滤波器范数',372)
 f.s.append('<circle cx="171" cy="221" r="100" fill="none" stroke="#9db9d1" stroke-width="2"/>')
 f.line(54,221,292,221);f.line(171,110,171,328)
 f.line(171,221,257.6,171,True,B);f.line(171,221,111,141,True,G)
 f.dot(171,221);f.text(307,172,'蓝线：原高斯权重',22,B,True)
 f.text(307,217,'绿线：Gabor 替换权重',22,G,True)
 f.text(307,277,'匹配长度，不约束后续训练。',20)
 f.text(29,350,'图中仅画两维方向，不是实际滤波器数值。',20,M)
 f.out('training-02-gabor')

 f=F('一个步数，不足以推出样本量','以下假定每步等于一次固定大小的 batch，仅作反例',327)
 f.chip(29,129,170,111,'1,100,000 步')
 for y,bs,count in [(110,16,'17,600,000 次呈现'),(206,64,'70,400,000 次呈现')]:
  f.line(207,183,268,y+35,True)
  f.text(282,y+21,f'假设 batch = {bs}',22,B,True);f.text(282,y+51,count,22)
 f.text(29,302,'真实 batch 与采样机制未知；样本呈现次数也非去重样本数。',18,R)
 f.out('training-03-missing')

 f=F('原图、实例与文字按同一坐标对齐','训练示意：example_0001，原图宽 640、高 480',399)
 f.box(33,113,328,246)
 f.box(115,174.5,123,123,'#e8c7a2',G,1);f.text(125,263,'obj_a',23,G,True)
 f.box(135.5,195,61.5,20.5,'white',B,1);f.text(139,211,'BOOK',13,B,True)
 f.line(241,267,382,267,True);f.text(393,275,'实例 → 名称 / 掩码',20,G)
 f.line(201,205,382,205,True);f.text(393,213,'文字框 → OCR 真值',20,B)
 f.text(29,385,'原图变换时，框和掩码也要同步变换。',20,M)
 f.out('training-04-sample')

 f=F('同一单词可以有多条 CTC 路径','合并连续重复，再移除空白 ∅',377)
 for j,(seq,word) in enumerate([('b b ∅ o o ∅ o k k','book'),('b ∅ b o o ∅ o k k','bbook'),('b ∅ o o ∅ o k k ∅','book')]):
  yy=111+j*66
  for i,t in enumerate(seq.split()):f.chip(29+i*47,yy,40,41,t,'white' if t=='∅' else P)
  f.line(461,yy+21,503,yy+21,True);f.text(518,yy+29,word,22,G if j!=1 else R,True)
 f.text(29,348,'训练对可得到 book 的路径概率求和，不先做贪心解码。',19)
 f.out('training-05-loss')

 f=F('总损失下降，也可能需要停下来','示意曲线；分开看两个指标的趋势，不比较数值大小',398)
 f.line(68,307,605,307,True);f.line(68,307,68,117,True)
 f.poly([(76,151),(160,179),(250,213),(349,239),(451,264),(551,278)],B)
 f.poly([(76,261),(160,228),(250,183),(349,190),(451,217),(551,243)],G)
 f.line(250,141,250,310,c=R,dash=True)
 f.text(260,128,'选更好的检查点',20,R,True)
 f.text(357,166,'OCR 验证表现（高好）',20,G)
 f.text(355,293,'训练总损失（低好）',20,B)
 f.text(461,340,'训练迭代',20)
 f.text(29,374,'关键任务退化时，回查分任务曲线再决定是否继续。',20,M)
 f.out('training-06-stop')

 f=F('训练更新与验证各走一条路线','参考训练控制结构，不是官方训练器',363)
 f.flow(['训练批','预测 / 真值','计算损失','反传更新'])
 f.line(28,204,612,204,c='#aabfd1',dash=True)
 f.text(28,238,'每轮结束，验证不参与反传：',22,N,True)
 f.flow(['验证批','关闭梯度','逐任务评测','选检查点'],263)
 f.out('training-07-loop')

 f=F('OCR 失败先区分漏检和读错','合成例：三条文字，两条有候选框',373)
 for i,(a,b,d,c) in enumerate([('BOOK','BOOK','命中且正确',G),('STOP','ST0P','命中但读错',R),('OPEN','无候选','漏检',R)]):
  y=116+i*58;f.chip(28,y,150,41,a);f.line(185,y+21,246,y+21,True);f.chip(255,y,175,41,b,T if c==G else O);f.text(452,y+28,d,21,c,True)
 f.text(28,314,'文字框召回：2 / 3；命中框整行识别：1 / 2。',22)
 f.text(28,346,'聚合成一个数字，会掩盖故障来源。',20,M)
 f.out('training-08-evaluation')

 f=F('发布采用混合精度，不是全 2-bit','条宽按位数绘制，不表示各组占模型总量的比例',355)
 for i,(n,v,c) in enumerate([('多数被量化矩阵',2,B),('Embedding / mHC',4,G),('HConvGLU 带状权重',16,'#6d52a0')]):
  yy=112+66*i;f.text(29,yy+26,n,20);f.box(253,yy,v*17,32,c,'none');f.text(262+v*17,yy+25,f'{v} bit',21,c,True)
 f.text(29,331,'还保留其他浮点张量；不能按统一位宽计算文件体积。',20,M)
 f.out('training-09-quant')

def api():
 f=F('同一 SDK 对接独立发布的两项产物','本包固定版本，避免误把旧引擎与当前包混用',331)
 f.chip(28,154,237,65,'Python SDK bb822a3')
 for yy,label,desc in [(111,'Engine 4.1.4','原生算子执行库'),(221,'Mirage 76c1e9…','独立模型权重')]:
  f.line(274,186,344,yy+25,True);f.chip(353,yy,253,50,label,'white');f.text(355,yy+80,desc,21,M)
 f.out('api-01-version')

 f=F('三个入口，调用同一个 describe','构造后得到实例；表单接口和模块函数都复用描述接口',360)
 for i,(a,b) in enumerate([('Mirage(weights=…)','构造后调用'),('extract(image, form)','验证并传入表单'),('cactus.describe(…)','按权重路径缓存')]):
  yy=108+i*75;f.chip(28,yy,213,46,a,P,18);f.line(246,yy+23,426,yy+23,True);f.text(270,yy+16,b,18)
 f.box(432,109,177,197,T)
 f.text(521,213,'实例 describe',21,N,True,'middle')
 f.out('api-02-python')

 f=F('五种图像输入归一为 RGB 像素','传不传显式宽高，决定 bytes 被如何解释',413)
 for x,t,items in [(28,'需要解码',['路径 / 压缩图片 bytes','Pillow Image','EXIF 旋转与 RGB 转换']),(329,'已经是像素',['uint8，形状 H×W×3','裸 bytes + 宽高','核对类型、通道与长度'])]:
  f.box(x,106,283,179)
  f.text(x+16,140,t,23,B,True)
  for i,it in enumerate(items):f.text(x+16,179+i*37,it,19)
  f.line(x+142,291,x+142,320,True)
 f.chip(112,327,416,45,'原图 RGB 连续缓冲 + W + H',T)
 f.text(29,398,'压缩图 bytes 不附宽高；裸 RGB 字节数必须为 3WH。',20,R)
 f.out('api-03-input')

 f=F('合并参数前，先查键的交集','同一个键从两处传入，不会被后者覆盖',334)
 f.chip(29,113,235,53,'options: {conf: .4}')
 f.chip(29,215,235,53,'settings: conf=.6')
 f.line(272,140,365,184,True);f.line(272,240,365,200,True)
 f.chip(374,169,235,53,'交集 = {conf}',O)
 f.text(375,266,'ValueError，未进入引擎',19,R,True)
 f.text(29,310,'无重键再编码 UTF-8 JSON；NaN / Inf 仍被拒绝。',20)
 f.out('api-04-options')

 f=F('阈值筛候选，不改变模型结构','教学分数；以 conf = 0.40 筛三个物体候选',354)
 for i,(a,v) in enumerate([('A',.22),('B',.61),('C',.88)]):
  yy=127+i*54;f.text(34,yy+23,a,22,N,True);f.box(100,yy,468*v,28,G if v>=.4 else R,'none');f.text(111+468*v,yy+22,f'{v:.2f}',19)
 f.line(287,115,287,278,c=R,dash=True);f.text(296,115,'阈值 0.40',18,R)
 f.text(29,323,'A 不通过；B、C 通过。名称是否正确仍需另查。',21)
 f.out('api-05-filter')

 f=F('从 0–1000 坐标还原到原图','示例 bbox = [250, 250, 625, 750]，原图 640 × 480',427)
 f.box(37,121,320,240,'white',M,0)
 for p in (.25,.5,.75):
  f.line(37+p*320,121,37+p*320,361,c='#ccdae5');f.line(37,121+p*240,357,121+p*240,c='#ccdae5')
 f.box(117,181,120,120,T,G,0);f.dot(117,181);f.dot(237,301)
 for y,t,c in [(158,'x 按 640 缩放',B),(204,'y 按 480 缩放',G),(262,'左上 (160, 120)',N),(311,'右下 (400, 360)',N)]:f.text(374,y,t,21,c)
 f.text(37,400,'只在确认返回格式为四元素 xyxy 后这样转换。',21,M)
 f.out('api-06-coordinates')

 f=F('线程能同时到达，原生调用仍串行','时间线示意：共享运行时 RLock',348)
 f.text(29,152,'线程 A');f.text(29,214,'线程 B')
 f.chip(128,121,215,49,'持锁推理 A')
 f.line(151,208,346,208,c=R,dash=True);f.text(191,197,'等待锁',19,R)
 f.chip(352,183,215,49,'持锁推理 B',T)
 f.line(128,260,595,260,True);f.text(522,292,'时间',20)
 f.text(29,327,'引擎失败时抛异常，不应读取上一次结果。',21,M)
 f.out('api-07-lock')

 f=F('两种 CLI 命令通向同一个模型','extract 读取表单文件，再把表单放入选项',345)
 f.chip(28,116,241,56,'describe：--options')
 f.chip(28,220,241,56,'extract：--form')
 f.line(276,144,391,181,True);f.line(276,248,391,209,True)
 f.chip(400,170,211,58,'model.describe()',T,19)
 f.text(279,276,'form → options',18)
 f.text(28,324,'标准输出是 JSON；异常和退出状态单独检查。',20,M)
 f.out('api-08-cli')

 f=F('应用逐图调用，结果行不能串图','同一实例循环处理，JSONL 每行保留当前输入状态',351)
 for i,(a,b,c,k) in enumerate([('001.png','调用','ok:true + result',T),('002.png','异常','ok:false + error',O),('003.png','调用','ok:true + result',T)]):
  yy=113+64*i;f.chip(29,yy,146,43,a);f.line(182,yy+21,219,yy+21,True);f.chip(226,yy,94,43,b,'white');f.line(327,yy+21,364,yy+21,True);f.chip(371,yy,238,43,c,k)
 f.text(28,328,'002 失败也要写自己的状态，不能沿用 001 的结果。',20)
 f.out('api-09-batch')

 f=F('离线启动需要三项文件','联网准备机取齐产物，再复制到离线目标机',361)
 for i,(a,b) in enumerate([('Python','wheel 与依赖'),('Engine','匹配系统 / 架构'),('Weights','校验 mirage.cact')]):
  x=28+i*198;f.box(x,117,188,88)
  f.text(x+94,153,a,23,B,True,'middle');f.text(x+94,184,b,18,M,False,'middle');f.line(x+94,213,x+94,244,True)
 f.chip(28,252,584,47,'离线目标机：本地文件路径 + 断网实测',T)
 f.text(28,333,'离线环境变量不会自动补齐缺失的文件。',20,R)
 f.out('api-10-offline')

 f=F('C ABI：模型与图片走不同入口','先加载模型，再传 RGB、参数和可写缓冲',363)
 for i,(a,b) in enumerate([('.cact 字节 + 长度','cactus_load'),('RGB / W / H / UTF-8','cactus_describe')]):
  yy=109+i*68;f.chip(28,yy,254,47,a);f.line(290,yy+24,343,yy+24,True);f.chip(352,yy,257,47,b,'white')
 f.text(28,265,'返回码 < 0 → cactus_last_error',23,R,True)
 f.text(28,302,'成功 → 解析输出缓冲中的 JSON',22,G,True)
 f.text(28,340,'输入与输出缓冲需在原生调用结束前保持有效。',20,M)
 f.out('api-11-abi')

 f=F('从最小样图到离线验收','每步都用可观察的结果定位问题',384)
 f.flow(['校验文件','跑单张图','断网复测','并发实测'],115)
 f.rows([('单图实测','核对图像方向、颜色与返回字段'),('断网实测','确认能加载本地文件，且不串前帧'),('并发实测','记录目标设备的延迟及内存')],193)
 f.out('api-12-checklist')

if __name__=='__main__':
 training();api()
