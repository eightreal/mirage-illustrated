# Mirage：代码、测试与离线运行

这里有两条互不替代的路径。要看**张量怎样算**，跑教学参考代码；要用**真正的 Mirage** 做识别，运行官方 API 调用示例，并提供对应平台的本地 SDK、二进制和权重。其中的教学权重为固定种子的随机数，不读取或模拟 `.cact` 量化权重，也没有正式识别能力。

## A. 教学参考实现

![教学参考实现](../assets/code-toy-training.png)

环境：Python 3.10 及以上、NumPy 1.24 及以上、Pillow 9.1 及以上；这两项如果已经装在本机，则下面的示例不访问网络。未打包 Python、第三方安装包或官方权重。本目录所有 `*.py` 均为独立编写的示例。

在本目录运行：

```sh
python mirage_reference.py
python mirage_reference.py --full-shapes --full-depth
python mirage_reference.py --image my_photo.png
python train_toy.py
python train_toy.py --output toy_head.npz
python -B -m unittest -v test_reference
```

如 NumPy 使用 OpenBLAS，Linux/macOS 可在上述命令前加 `OPENBLAS_NUM_THREADS=1`，Windows PowerShell 可先设 `$env:OPENBLAS_NUM_THREADS = "1"`。这些设置只影响运行时间。

- `mirage_reference.py`：上/左对齐的教学 letterbox，五次 stride 2；body 的空间 depthwise 门控、Hadamard 带状门控及 GRN；四个寄存 token、单 KV 组 GQA 与跨层 memory；E 和 S16、S8 两次融合后输出 D；检测、P/C 两支、实例掩码点积、区域 token。全尺寸模式可输出 E = 16×16×512、T32 = 32×32×128、D = 64×64×128、P = 128×128×32、C = 64×64×32；默认模式减小分辨率和通道数。小模式的 `T32` 变量名指全尺寸图中的 32×32 级，对应 stride 16。
- `decoder_ops.py`：可独立检查的数字示例。Engram 哈希索引只依赖当前及过去 n-gram；Q/K/V 投影后时间混合只读当前及历史；用固定视觉 K/V 的注意力读图；枚举完整路径的 log P 求和；OCR 裁窗偏移与 `mirage_reference.ctc_greedy` 的 CTC 去重。它**不是**八层解码器或完整 OCR 模型：没有原生 tokenizer、查表权重、mHC 和语义文本生成，也不实现厂商的重叠窗接缝合并。
- `train_toy.py`：生成小色块图像、从 D 提取特征，冻结其它参数，仅训练一个热图线性头。默认训练 20 张、独立测试 8 张合成图；用手写加权 BCE 梯度更新。一次验证运行损失从 0.6931 降到 0.1809，测试热图最高点命中率 0.500。它验证样例确实会做参数更新，不说明可对真实图片检测，也不是官方训练方式。导出的 `.npz` 是这个教学头，与官方 `.cact` 不兼容。

有意简化：若干归一化增益与各投影偏置省略；Walsh 使用 Sylvester 顺序，带状算子采用零边界；插值选择最近邻，RoPE 用 1D 连续位置，寄存 token 位置安排、模式匹配/过滤、区域 token 的引用嵌入及原生 KV 实现均未复制。检测头只输出两类教学数值，未执行原生阈值/NMS/重映射；示例框为相对 letterbox 画布的未裁剪 XYXY，不是 API 的 0–1000 坐标。区域记忆池化用离散网格平均，未加编号 token 嵌入。P/C 与 mask 概率也不代表有意义的分割，未实现官方掩码裁剪、连通域及轮廓后处理。看代码时，请把真实尺寸和算子结构与可识别性、参数兼容性分开。

## B. 官方调用示例

![官方调用示例](../assets/code-native-boundary.png)

已有本机兼容的 `cactus-compute` Python 包、兼容 Cactus 4 风格 ABI 的本机动态库和合法取得的 Mirage 权重时：

```sh
python official_api_demo.py --image image.png --weights /path/mirage.cact --library /path/libcactus.so --action objects
python official_api_demo.py --image sign.png --weights /path/mirage.cact --library /path/libcactus.so --action form
python native_ctypes_demo.py --image image.png --weights /path/mirage.cact --library /path/libcactus.so
```

动态库扩展名随平台变化，匹配操作系统、处理器架构、SDK/权重版本；明确指定本地库和权重，避开默认自动拉取资源。Python 示例处理 `describe` 与 `extract`；ctypes 示例不依赖 Python SDK（以 Pillow 将图片转换为 RGB），直接绑定 `cactus_load` / `cactus_models` / `cactus_describe` / `cactus_last_error`。接口行为若随 SDK 版本变化，以所用版本为准；不要混用旧版本的 C 头文件。

验证状态：上述 9 项本地测试已通过。全尺寸 16 body + 12 attention 实跑并断言形状；教学训练实跑；两个官方调用示例只通过替身测试核对参数与错误隔离，**没有**在此环境以官方模型、原生动态库或 NPU 实测。

[返回项目目录](../README.md)
