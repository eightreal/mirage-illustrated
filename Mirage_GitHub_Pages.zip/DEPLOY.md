# 部署与维护

此目录本身是可以提交到新 GitHub 仓库的根目录。静态文件已生成，无需在 GitHub 上安装依赖，也不需要自定义 Actions。发布前复核你选择的仓库可见性；即使仓库设为 private，Pages 网站也不保证是私有的。

1. 将本目录内容提交到新仓库的 `main` 分支（不要另嵌一个外层目录）。
2. 在该仓库打开 **Settings → Pages → Build and deployment**。在 **Source** 选 **Deploy from a branch**，选 **main** 和 **/docs** 并保存。
3. 等待 Pages 部署成功，再用 Settings 页面显示的站点地址打开。项目网站的默认地址通常为 `https://<owner>.github.io/<repository>/`，不是仓库的文件浏览地址。
4. 确认首页、实现章 GQA 公式、本地图片原图链接及代码下载均可打开。

`docs/index.html` 为站点入口；`docs/.nojekyll` 保留原样静态发布。正文、图片、MathML、下载链接均在仓库中。不要对 GitHub 路径添加绝对前缀（如 `/assets/`），否则仓库前缀部署会丢失资源。

## 本地维护

所有可编辑 Markdown、PNG/SVG、图稿生成脚本、代码、上游文件均在 `source/`。修改后，从仓库根目录运行：

```sh
python3 tools/build_pages.py
python3 tools/smoke_pages.py
```

重建要求 Python 3.9+、Pandoc 和兼容 POSIX 的 `sh`。HTTP 检查只用 Python 标准库，使用本机回环和模拟仓库子路径，不连接 GitHub。更新后把 `source/` 和 `docs/` 的变化一起提交；默认站点已生成，首次部署不必重建。

操作路径依据 GitHub Docs 的 “Configuring a publishing source for your GitHub Pages site”。
