# Mirage 图解技术文档

中文技术项目，含模型结构、逐块实现与数学、训练和复现边界、Python／CLI／C 接口、模型元数据与可运行教学代码。按官方发布材料和固定版本源码核查；不是官方原版训练仓库。

| 阅读或维护 | 入口 |
|---|---|
| 五章原始 Markdown 与全部插图 | [source/README.md](source/README.md) |
| GitHub Pages 静态输出 | [docs/index.html](docs/index.html)（GitHub 仓库内此链接会展示文件；网页从 Pages 地址打开） |
| Python 教学机制与本地测试 | [source/code/README.md](source/code/README.md) |
| 官方 SDK 快照与许可证 | [source/upstream/README.md](source/upstream/README.md) |
| 发布和维护 | [DEPLOY.md](DEPLOY.md) |

不含下载凭据、真实模型权重或预编译引擎。两个 toy 文件是合成教学数据，不是官方权重。
