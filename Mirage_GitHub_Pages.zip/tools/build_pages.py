"""Rebuild committed GitHub Pages static files locally; requires Python and Pandoc."""
from html.parser import HTMLParser
from pathlib import Path
from shutil import copy2, copytree, rmtree
from subprocess import run
from tempfile import TemporaryDirectory
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source"
PUBLIC = ROOT / "docs"
CODE = (
    "README.html", "mirage_reference.py", "decoder_ops.py", "train_toy.py",
    "test_reference.py", "native_ctypes_demo.py", "official_api_demo.py", "requirements.txt",
)
UPSTREAM = (
    "README.html", "LICENSE-Apache-2.0.txt", "cactus-sdk-bb822a3.tar.gz",
    "source/LICENSE", "source/cactus/agent/audio.py", "source/cactus/agent/mirage.py",
    "source/cactus/agent/runtime.py", "source/cactus/cli/parser.py",
    "source/cactus/cli/vision.py", "source/tests/test_mirage.py",
)
META = (
    "config.json", "model_files.json", "tensor_manifest.json", "tensor_summary.csv",
    "toy_memory.json", "toy_model.npz", "verify_examples.py",
)

class HtmlAssets(HTMLParser):
    def __init__(self):
        super().__init__()
        self.files = set()

    def handle_starttag(self, tag, attrs):
        if tag != "img":
            return
        u = urlsplit(dict(attrs).get("src", ""))
        assert not u.scheme and not u.netloc, u
        p = Path(unquote(u.path))
        assert p.suffix == ".png" and p.parent.name == "assets" and p.name, p
        self.files.add(p.name)

def copy(source, target):
    assert source.is_file() and not source.is_symlink(), source
    target.parent.mkdir(parents=True, exist_ok=True)
    copy2(source, target)

def append_block(page, title, items, prefix=""):
    links = "".join(f'<li><a download href="{prefix}{name}"><code>{name}</code></a></li>' for name in items)
    return page.replace("</body>", f'<section class="downloads"><h2>{title}</h2><ul>{links}</ul></section>\n</body>')

with TemporaryDirectory(prefix="mirage-pages-") as temp:
    work = Path(temp) / "source"
    site = Path(temp) / "docs"
    copytree(SOURCE, work)
    run(["sh", "tools/build_html.sh"], cwd=work, check=True)
    site.mkdir()
    (site / ".nojekyll").touch()
    (site / "chapters").mkdir()
    (site / "code").mkdir()
    (site / "upstream").mkdir()

    index = (work / "打开这里.html").read_text(encoding="utf-8")
    index = index.replace('href="docs/', 'href="chapters/')
    index = index.replace(
        "在 GitHub 上从下方目录阅读；离线时，解压后打开",
        "从下方目录阅读。原始 Markdown 在仓库的 source/ 中；使用离线资料包时打开",
    )
    index = append_block(index, "下载模型元数据和教学样例", META, "model-metadata/")
    (site / "index.html").write_text(index, encoding="utf-8")

    for chapter in sorted((work / "docs").glob("*.html")):
        html = chapter.read_text(encoding="utf-8").replace("../打开这里.html", "../index.html")
        (site / "chapters" / chapter.name).write_text(html, encoding="utf-8")

    for folder, names in [("code", CODE), ("upstream", UPSTREAM), ("model-metadata", META)]:
        for name in names:
            path = site / folder / name
            if name == "README.html":
                html = (work / folder / name).read_text(encoding="utf-8").replace("../打开这里.html", "../index.html")
                if folder == "code":
                    html = append_block(html, "下载教学代码", CODE[1:])
                else:
                    html = append_block(html, "下载官方 SDK 归档和许可证", UPSTREAM[1:3])
                path.write_text(html, encoding="utf-8")
            else:
                copy(work / folder / name, path)

    pict = HtmlAssets()
    for page in site.rglob("*.html"):
        pict.feed(page.read_text(encoding="utf-8"))
    for name in sorted(pict.files):
        copy(work / "assets" / name, site / "assets" / name)

    if PUBLIC.exists():
        rmtree(PUBLIC)
    copytree(site, PUBLIC)
    print(f"Generated {len(list(PUBLIC.rglob('*.html')))} pages and {len(pict.files)} images")
