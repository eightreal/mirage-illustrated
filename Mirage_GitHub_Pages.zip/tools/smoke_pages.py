"""Read all local static links/anchors under a simulated GitHub repository prefix."""
import argparse
from functools import partial
from html.parser import HTMLParser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from shutil import copytree
from tempfile import TemporaryDirectory
from threading import Thread
from urllib.parse import quote, unquote, urljoin, urlsplit
from urllib.request import ProxyHandler, build_opener

ROOT = Path(__file__).resolve().parents[1] / "docs"
PREFIX = "/mirage-prefix-smoke-test/"
STANDARD = ["index.html", "chapters/01-architecture.html", "chapters/02-implementation.html",
            "chapters/03-training.html", "chapters/04-api.html", "chapters/05-model-files.html",
            "code/README.html", "upstream/README.html"]

class Page(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.links = []
        self.ids = set()
        self.math = 0
        self.img = 0
        self.feed(html)

    def handle_starttag(self, tag, data):
        attrs = dict(data)
        self.ids.update(v for n, v in data if n == "id" and v)
        if tag == "math":
            self.math += 1
        if tag == "img":
            assert attrs.get("alt"), "Each image must have a meaningful alt label"
            self.img += 1
        for prop in ("src", "href", "poster", "data"):
            url = attrs.get(prop)
            if url:
                self.links.append(url)
        assert tag not in {"script", "iframe", "base"}, f"Unexpected active element {tag}"

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

def audit(base, fetch):
    assert (ROOT / ".nojekyll").is_file()
    seen = {}
    pages = {}
    def get(u):
        key = u.partition("#")[0]
        if key not in seen:
            seen[key] = fetch(key)
            assert seen[key], f"empty {key}"
        return seen[key]
    def get_page(u):
        key = u.partition("#")[0]
        if key not in pages:
            pages[key] = Page(get(key).decode("utf-8"))
        return pages[key]
    assert get(base) == get(urljoin(base, "index.html"))
    for file in STANDARD:
        get_page(urljoin(base, file))
    assert get_page(urljoin(base, "chapters/02-implementation.html")).math >= 10
    assert sum(p.img for p in pages.values()) >= 60
    for f in ROOT.rglob("*.html"):
        get_page(urljoin(base, quote(f.relative_to(ROOT).as_posix())))
    for owner, page in list(pages.items()):
        for link in page.links:
            ref = urlsplit(link)
            assert not ref.scheme and not ref.netloc and not ref.path.startswith("/"), (owner, link)
            u = urljoin(owner, link)
            assert u.startswith(base), (owner, link, u)
            content = get(u)
            if urlsplit(u).path.endswith(".png"):
                assert content.startswith(b"\x89PNG\r\n\x1a\n"), u
            anchor = unquote(urlsplit(u).fragment)
            if anchor and urlsplit(u).path.endswith(".html"):
                assert anchor in get_page(u).ids, (owner, link, anchor)
    for p in ROOT.rglob("*"):
        assert not p.is_symlink()
        assert p.suffix not in {".cact", ".safetensors", ".so", ".dll", ".dylib", ".exe", ".whl"}
    for file in ("model-metadata/config.json", "model-metadata/tensor_manifest.json",
                 "code/mirage_reference.py", "upstream/cactus-sdk-bb822a3.tar.gz"):
        get(urljoin(base, file))
    print(f"PASS {len(pages)} HTML pages, {len(seen)} resolved resources, "
          f"{sum(p.img for p in pages.values())} figure placements")

def simulate_http():
    with TemporaryDirectory(prefix="mirage-pages-smoke-") as tmp:
        copytree(ROOT, Path(tmp) / PREFIX.strip("/"))
        with ThreadingHTTPServer(("127.0.0.1", 0), partial(QuietHandler, directory=tmp)) as server:
            thread = Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                opener = build_opener(ProxyHandler({}))
                def response(u):
                    with opener.open(u, timeout=5) as res:
                        assert res.status == 200
                        return res.read()
                audit(f"http://127.0.0.1:{server.server_port}{PREFIX}", response)
                print("Transport: actual loopback HTTP under repository path")
            finally:
                server.shutdown(); thread.join()

def simulate_read():
    base = "https://example.invalid" + PREFIX
    def read(u):
        rel = unquote(urlsplit(u).path[len(PREFIX):]) or "index.html"
        p = (ROOT / rel).resolve()
        assert p.is_relative_to(ROOT)
        return p.read_bytes()
    audit(base, read)
    print("Transport: URI resolution and local read (not HTTP)")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--local-only", action="store_true", help="Validate via local reads if loopback is unavailable")
    args = parser.parse_args()
    simulate_read() if args.local_only else simulate_http()
