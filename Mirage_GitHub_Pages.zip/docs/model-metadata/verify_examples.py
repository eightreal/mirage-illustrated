import json,math
from pathlib import Path
p=Path(__file__).parent
j=json.loads((p/'tensor_manifest.json').read_text())
t=[v for k,v in j.items() if k!='__metadata__']
assert len(t)==583
assert sum(math.prod(v['shape']) for v in t)==54078804
assert max(v['data_offsets'][1] for v in t)==216315216
assert 8+55280+216315216==216370504
a=json.loads((p/'toy_memory.json').read_text())
z=[x+y for x,y in zip(a['u'],a['v'])]
r=math.sqrt(sum(x*x for x in z)/len(z))
out=[x/r+math.sqrt(2)*e for x,e in zip(z,a['ref'])]
assert max(abs(x-y) for x,y in zip(out,a['slot']))<1e-12
assert 68+56+56+56+64==300
assert 512*65*3+512==100352
assert 512*65-2*sum(range(1,33))==32224
assert 54078804-2559714-262144==51256946
print('PASS: 真实文件尺寸/张量计数与教学slot/计算量断言')

assert j["top_0/self_attn/q_proj/kernel"]["shape"] == [512,128]
assert j["top_0/self_attn/k_proj/kernel"]["shape"] == [512,32]
assert j["top_0/self_attn/v_proj/kernel"]["shape"] == [512,64]
assert j["top_0/self_attn/out_proj/kernel"]["shape"] == [256,512]
print("PASS: Attention投影尺寸已与真实header逐项校对")
