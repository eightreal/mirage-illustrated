"""Independent ctypes example for the Cactus 4-style cactus_* C ABI."""
import argparse
import ctypes as ct
import json
from pathlib import Path


def load_native(library):
    lib = ct.CDLL(str(library.resolve()))
    lib.cactus_models.argtypes = []
    lib.cactus_models.restype = ct.c_int
    lib.cactus_last_error.argtypes = []
    lib.cactus_last_error.restype = ct.c_char_p
    lib.cactus_load.argtypes = [ct.c_void_p,ct.c_ulonglong]
    lib.cactus_load.restype = ct.c_int
    lib.cactus_describe.argtypes = [ct.c_void_p,ct.c_int,ct.c_int,ct.c_char_p,
                                   ct.c_char_p,ct.c_char_p,ct.c_void_p,ct.c_int]
    lib.cactus_describe.restype = ct.c_int
    return lib


def check(lib, code, where):
    if code < 0:
        message = lib.cactus_last_error() or b''
        raise RuntimeError(f'{where}: {message.decode("utf-8","replace")}')


def invoke(lib, archive, rgb, w, h, options, language=None, keywords=None, capacity=16*1024*1024):
    if len(rgb) != w*h*3 or min(w,h) < 1:
        raise ValueError("packed RGB length must equal width x height x 3")
    if not 0 < capacity <= 2**31-1:
        raise ValueError("invalid output capacity")
    model = ct.create_string_buffer(archive)
    check(lib,lib.cactus_load(model,len(archive)), "cactus_load")
    if not lib.cactus_models() & 4:
        raise ValueError("native library did not report the vision model bit")
    pixels = ct.create_string_buffer(rgb)
    output = ct.create_string_buffer(capacity)
    options_json = json.dumps(options,ensure_ascii=False,allow_nan=False).encode('utf-8')
    check(lib,lib.cactus_describe(pixels,w,h,options_json,
             language.encode() if language else None,keywords.encode() if keywords else None,
             output,capacity),"cactus_describe")
    return json.loads(output.value.decode('utf-8'))


def main():
    from PIL import Image,ImageOps
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--library',type=Path,required=True)
    p.add_argument('--weights',type=Path,required=True)
    p.add_argument('--image',type=Path,required=True)
    p.add_argument('--options',default='{"sections":["objects","text"]}')
    p.add_argument('--language')
    a = p.parse_args()
    with Image.open(a.image) as src:
        im = ImageOps.exif_transpose(src).convert('RGB')
        rgb,w,h = im.tobytes(), im.width,im.height
    result=invoke(load_native(a.library),a.weights.read_bytes(),rgb,w,h,json.loads(a.options),a.language)
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
