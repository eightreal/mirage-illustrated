"""Call an already-installed Cactus SDK with an explicitly selected model."""
import argparse
import json
import os
from pathlib import Path


def run(model,image,action):
    if action=='objects':
        return model.describe(image, sections=["objects","text"], fields=["bbox","score","mask"],
                              mask_format="polygons")
    if action=='form':
        return model.extract(image, {"sign":{"enum":["stop","yield","speed limit"]}})
    raise ValueError(action)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--image",type=Path,required=True)
    p.add_argument("--weights",type=Path,required=True,help="local mirage.cact")
    p.add_argument("--library",type=Path,required=True,help="local lib with cactus_* ABI")
    p.add_argument("--action",choices=("objects","form"),default="objects")
    a = p.parse_args()
    for label in ("image","weights","library"):
        if not getattr(a,label).is_file():
            p.error(f"{label} is not a regular file: {getattr(a,label)}")
    os.environ["CACTUS_LIB_PATH"] = str(a.library.resolve())
    try:
        from cactus import Mirage
    except ImportError as e:
        raise SystemExit("先在本机安装含 Mirage 类的 cactus-compute 发行版；此压缩包未捆绑运行库。") from e
    print(json.dumps(run(Mirage(weights=a.weights.resolve()),str(a.image.resolve()),a.action),
                     ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
