"""Illustrative numerical primitives; not an eight-layer generative decoder."""
import numpy as np
from mirage_reference import softmax, rms


def engram_ids(tokens, orders=(2,3), heads=2, rows=18432):
    """Illustrative hash only; not compatible with the native lookup table."""
    if rows < 1 or heads < 1 or any(o < 1 for o in orders):
        raise ValueError("invalid hash table dimensions")
    ids=np.full((len(tokens),len(orders),heads),-1,dtype=np.int64)
    for t in range(len(tokens)):
        for i,order in enumerate(orders):
            if t+1<order:
                continue
            for h in range(heads):
                value=2166136261 + 257*h + 31*order
                for tok in tokens[t+1-order:t+1]:
                    value=((value ^ int(tok))*16777619) & 0xffffffff
                ids[t,i,h]=value%rows
    return ids


def causal_projected_mix(projected, taps):
    """Temporal depthwise lag mix after the Q, K, or V projection.
    projected[T,H,D], taps[L,H,D]; tap 0 acts on the current token.
    """
    if projected.ndim!=3 or taps.ndim!=3 or projected.shape[1:]!=taps.shape[1:]:
        raise ValueError("incompatible projected array / taps dimensions")
    out=np.zeros_like(projected)
    for j in range(min(len(taps),len(projected))):
        out[j:] += projected[:len(projected)-j]*taps[j]
    return out


def cross_attention(q, keys, values, valid):
    """Simple single-head read to show static image K/V reused by all queries."""
    valid=np.asarray(valid,dtype=bool)
    if valid.shape!=(len(keys),) or not valid.any() or len(keys)!=len(values):
        raise ValueError("expected at least one valid matching image key/value")
    logits=rms(q)@rms(keys).T / np.sqrt(keys.shape[-1])
    logits[:,~valid]=-np.inf
    return softmax(logits)@values


def enum_probabilities(option_logprobs):
    """One list per candidate; caller must include termination in each list.
    Each token log P must use its own candidate-conditioned prefix.
    """
    if not option_logprobs or any(not len(path) for path in option_logprobs):
        raise ValueError("each option needs at least one log probability")
    scores=np.array([sum(path) for path in option_logprobs],dtype=np.float64)
    if np.isnan(scores).any() or np.isposinf(scores).any() or not np.isfinite(scores).any():
        raise ValueError("at least one viable finite score is required")
    return softmax(scores)


def window_plan(resized_width, window=320, overlap=96):
    """Example OCR crop offsets; stride = 224 at the documented defaults."""
    if resized_width<1 or not 0<=overlap<window:
        raise ValueError("invalid crop or overlap")
    windows = [(0,min(resized_width,window))]
    while windows[-1][1]<resized_width:
        start=windows[-1][0]+window-overlap
        windows.append((start,min(start+window,resized_width)))
    return windows
