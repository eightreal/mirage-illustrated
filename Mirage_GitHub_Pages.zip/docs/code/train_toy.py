"""Reproducible SGD example: train one detection heatmap readout, not Mirage."""
import argparse
import numpy as np
from mirage_reference import Reference, sigmoid


def dataset(rng, n, seed=7):
    model = Reference(size=64, seed=seed)
    feats, labels = [], []
    for _ in range(n):
        row,col = rng.integers(0,8,size=2)
        image = rng.integers(10,40,size=(64,64,3),dtype=np.uint8)
        image[8*row:8*row+8,8*col:8*col+8] = [245,130,30]
        d = model(image)['D']
        label = np.zeros(d.shape[:2],dtype=np.float32)
        label[row,col] = 1
        feats.append(d.reshape(-1,d.shape[-1]))
        labels.append(label.ravel())
    return np.concatenate(feats),np.concatenate(labels)


def loss_gradient(x,y,w,b):
    z = x@w + b
    # Balance positives and negatives; there is one positive per 8×8 grid.
    a = np.where(y>0.5,8.,1.)
    loss = (a*(np.logaddexp(0,z)-y*z)).sum()/a.sum()
    delta = (sigmoid(z)-y)*a/a.sum()
    return float(loss), x.T@delta, float(delta.sum())


def train(epochs=100,lr=0.4):
    rng = np.random.default_rng(23)
    x,y = dataset(rng,20)
    xv,yv = dataset(rng,8)
    w = np.zeros(x.shape[-1])
    b = 0.0
    before = loss_gradient(xv,yv,w,b)[0]
    for _ in range(epochs):
        _,dw,db = loss_gradient(x,y,w,b)
        w -= lr*dw
        b -= lr*db
    after = loss_gradient(xv,yv,w,b)[0]
    scores = (xv@w+b).reshape(-1,64)
    ref = yv.reshape(-1,64)
    top1 = (scores.argmax(axis=1)==ref.argmax(axis=1)).mean()
    return before,after,top1,w,b


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs',type=int,default=100)
    parser.add_argument('--lr',type=float,default=0.4)
    parser.add_argument('--output',help='optional .npz destination; not a .cact file')
    a = parser.parse_args()
    if a.epochs < 1 or a.lr <= 0:
        parser.error('epochs and lr must be positive')
    before,after,top1,w,b=train(a.epochs,a.lr)
    print(f'Toy held-out weighted BCE {before:.4f} -> {after:.4f}; peak-cell accuracy {top1:.3f}')
    if a.output:
        np.savez(a.output, weight=w,bias=b)


if __name__=='__main__':
    main()
