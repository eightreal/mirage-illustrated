import unittest
import numpy as np
from mirage_reference import Reference, toy_image, hadamard, band, ctc_greedy, instance_mask
from decoder_ops import engram_ids, causal_projected_mix, cross_attention, enum_probabilities, window_plan
from official_api_demo import run
from native_ctypes_demo import invoke
from train_toy import train, loss_gradient


class ReferenceTests(unittest.TestCase):
    def test_hadamard_is_orthogonal(self):
        x=np.arange(16,dtype=np.float32).reshape(2,8)
        np.testing.assert_allclose(hadamard(hadamard(x)),x,rtol=1e-6,atol=1e-6)

    def test_banded_uses_zero_boundary(self):
        x=np.array([1,2,3],dtype=np.float32)
        np.testing.assert_allclose(band(x,np.ones((3,3))),[3,6,5])

    def test_feature_branches_and_padding(self):
        model=Reference()
        out=model(toy_image())
        self.assertEqual(out['E'].shape,(4,4,128))
        self.assertEqual(out['T32'].shape,(8,8,32))
        self.assertEqual(out['D'].shape,(16,16,32))
        self.assertEqual(out['P'].shape,(32,32,32))
        self.assertEqual(out['C'].shape,(16,16,32))
        self.assertEqual(out['valid_coarse'].sum(),12)
        self.assertFalse(out['E'][~out['valid_coarse']].any())
        self.assertEqual(model.region_tokens(out,[(3,4,(.2,.2,.7,.5))]).shape,(17,128))
        self.assertEqual(instance_mask(out,3,4).shape,(32,32))

    def test_full_shape_depth(self):
        m=Reference(size=512,channels=(32,64,128,256,512),body_count=16,attention_count=12)
        out=m(toy_image())
        for name,expected in dict(S4=(128,128,64),S8=(64,64,128),S16=(32,32,256),
                                  F5=(16,16,512),E=(16,16,512),T32=(32,32,128),
                                  D=(64,64,128),P=(128,128,32),C=(64,64,32)).items():
            self.assertEqual(out[name].shape,expected)
            self.assertTrue(np.isfinite(out[name]).all())

    def test_greedy_ctc_keeps_repeated_chars_separated_by_blank(self):
        self.assertEqual(ctc_greedy(np.eye(3)[[1,1,0,1,2,2]],'AB'),'AAB')

    def test_training_loss_and_gradient(self):
        x=np.array([[1.5,2],[1,0],[-1,1.4]])
        y=np.array([1,0,0])
        w=np.array([.3,.4])
        loss, grad, _=loss_gradient(x,y,w,0)
        finite=(loss_gradient(x,y,w+[1e-5,0],0)[0]-loss)/1e-5
        self.assertAlmostEqual(grad[0],finite,places=5)
        first,last, *_ = train(20)
        self.assertLess(last,first)

    def test_ngrams_causal_mixing_enum_and_windows(self):
        tokens=[11,23,11,99]
        np.testing.assert_array_equal(engram_ids(tokens)[:2],engram_ids(tokens[:2]))
        mixed=causal_projected_mix(np.array([1,2,3])[:,None,None],np.ones((3,1,1),dtype=int))
        np.testing.assert_array_equal(mixed[:,0,0],[1,3,6])
        probs=enum_probabilities([[-.1,-.4],[-.3,-.3]])
        self.assertGreater(probs[0],probs[1])
        self.assertAlmostEqual(probs.sum(),1.0)
        self.assertEqual(window_plan(700),[(0,320),(224,544),(448,700)])
        self.assertEqual(window_plan(100),[(0,100)])
        np.testing.assert_allclose(cross_attention(np.array([[1,1]]),np.eye(2),np.array([[3],[6]]),[1,0]),[[3]])

    def test_official_sdk_usage_with_stub(self):
        class SDK:
            def describe(self,image,**options):
                return options
            def extract(self,image,form):
                return form
        self.assertEqual(run(SDK(),'image.png','objects')['mask_format'],'polygons')
        self.assertEqual(run(SDK(),'image.png','form')['sign']['enum'][0],'stop')

    def test_native_contract_with_stub(self):
        class Lib:
            def cactus_load(self,model,n):
                return 0 if model.raw[:n]==b'CACT' else -1
            def cactus_models(self):
                return 4
            def cactus_describe(self,rgb,w,h,options,lang,kw,out,capacity):
                self.values=(rgb.raw[:w*h*3],options,lang)
                out.value=b'{"objects":[]}'
                return 0
        lib=Lib()
        out=invoke(lib,b'CACT',b'\1\2\3',1,1,{'sections':['objects']},'en',capacity=64)
        self.assertEqual(out,{'objects':[]})
        self.assertEqual(lib.values,(b'\1\2\3',b'{"sections": ["objects"]}',b'en'))


if __name__=='__main__':
    unittest.main()
