"""Educational forward only; random weights. Never loads .cact archives."""
from __future__ import annotations

import argparse
import json
import numpy as np


def sigmoid(x):
    return 1 / (1 + np.exp(-np.clip(x, -50, 50)))


def silu(x):
    return x * sigmoid(x)


def gelu(x):
    return 0.5 * x * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x**3)))


def rms(x, eps=1e-6):
    return x / np.sqrt(np.mean(x*x, axis=-1, keepdims=True) + eps)


def softmax(x):
    v = np.exp(x - x.max(axis=-1, keepdims=True))
    return v / v.sum(axis=-1, keepdims=True)


def letterbox(image, size):
    from PIL import Image
    if image.ndim != 3 or image.shape[2] != 3 or image.dtype != np.uint8:
        raise ValueError("expected RGB uint8 image")
    h, w = image.shape[:2]
    if min(h, w) < 1:
        raise ValueError("empty image")
    scale = size / max(h, w)
    rh, rw = max(1, round(h*scale)), max(1, round(w*scale))
    resized = Image.fromarray(image).resize((rw, rh), Image.Resampling.BILINEAR)
    # Teaching choices: upper-left placement, uint8 zero fill and bilinear resize.
    result = np.zeros((size, size, 3), dtype=np.uint8)
    result[:rh, :rw] = np.asarray(resized)
    return result.astype(np.float32)/127.5 - 1, (rh, rw)


def valid_mask(size, stride, resized_hw):
    rh, rw = resized_hw
    return ((np.arange(size)[:, None] * stride < rh) &
            (np.arange(size)[None, :] * stride < rw))


def patches(x, stride):
    xp = np.pad(x, ((1, 1), (1, 1), (0, 0)))
    return np.lib.stride_tricks.sliding_window_view(xp, (3, 3), axis=(0, 1))[::stride, ::stride]


def full3x3(x, weight, stride=1):
    return np.einsum('ijcyx,cyxo->ijo', patches(x, stride), weight, optimize=True)


def depthwise(x, weight, stride=1):
    return np.einsum('ijcyx,cyx->ijc', patches(x, stride), weight)


def up2(x):
    # Nearest-neighbor for reproducibility; parity with native interpolation not claimed.
    return x.repeat(2, axis=0).repeat(2, axis=1)


def hadamard(x):
    """Normalized fast Walsh-Hadamard transform in Sylvester order."""
    n = x.shape[-1]
    if n < 1 or n & (n-1):
        raise ValueError("channel dimension must be a power of two")
    y = np.ascontiguousarray(x, dtype=np.float32).copy()
    width = 1
    while width < n:
        view = y.reshape(-1, n//(2*width), 2, width)
        left, right = view[:, :, 0].copy(), view[:, :, 1].copy()
        view[:, :, 0], view[:, :, 1] = left+right, left-right
        width *= 2
    return y / np.float32(np.sqrt(n))


def band(x, weights):
    """Zero-boundary per-output bands: output[j] = sum_t w[j,t] x[j+t]."""
    rad = weights.shape[-1]//2
    padding = [(0,0)]*(x.ndim-1) + [(rad,rad)]
    windows = np.lib.stride_tricks.sliding_window_view(np.pad(x, padding), 2*rad+1, axis=-1)
    return np.einsum('...ct,ct->...c', windows, weights)


def rope(x, positions):
    """Illustrative 1-D RoPE; native image/register indexing is not replicated."""
    half = x.shape[-1]//2
    inv_freq = (10000.0 ** (-np.arange(half)/half)).astype(np.float32)
    theta = positions[:,None]*inv_freq[None,:]
    if x.ndim == 3:
        theta = theta[:,None,:]
    a,b = x[...,:half], x[...,half:]
    return np.concatenate([a*np.cos(theta)-b*np.sin(theta),
                           a*np.sin(theta)+b*np.cos(theta)], axis=-1)


class Reference:
    def __init__(self, size=128, body_count=2, attention_count=2, seed=7, channels=(8,16,32,64,128)):
        if size < 32 or size % 32:
            raise ValueError("size must be a positive multiple of 32")
        self.size, self.channels = size, channels
        self.body_count, self.attention_count = body_count, attention_count
        self.dense, self.hidden = channels[2], channels[4]
        self.qk, self.value = (32,64) if self.hidden == 512 else (8,16)
        self.band_radius = 32 if self.hidden == 512 else 4
        self.rg = np.random.default_rng(seed)
        self.params = {}

    def p(self, key, shape, magnitude):
        if key not in self.params:
            self.params[key] = self.rg.standard_normal(shape, dtype=np.float32)*np.float32(magnitude)
        return self.params[key]

    def linear(self, x, key, out):
        return x @ self.p(key, (x.shape[-1],out), .35/np.sqrt(x.shape[-1]))

    def dw(self, x, key, stride=1):
        return depthwise(x, self.p(key, (x.shape[-1],3,3), .35/3), stride)

    def stem(self,x,hw):
        features = []
        for i,c in enumerate(self.channels):
            if i == 0:
                x = full3x3(x, self.p('stem.initial',(3,3,3,c), .35/np.sqrt(27)),2)
            else:
                x = self.linear(self.dw(silu(x),f'stem.dw{i}',2),f'stem.pw{i}',c)
            x = rms(x) * valid_mask(x.shape[0],2**(i+1),hw)[...,None]
            features.append(x)
        return features

    def hc(self,x, key):
        u = hadamard(x)
        width = self.band_radius*2 + 1
        def apply_band(z, branch):
            return band(z,self.p(key+'.'+branch,(x.shape[-1],width), .35/np.sqrt(width)))
        # Native Walsh channel order deliberately not asserted by this implementation.
        g = gelu(apply_band(u,'gate') + self.p(key+'.bias',(x.shape[-1],),0.02))
        v = apply_band(u,'value')
        return hadamard(apply_band(v*g,'out'))

    def body(self,x,mask,i):
        prefix = f'body.{i}'
        nx = rms(x)
        z = self.dw(nx,prefix+'.v') * silu(self.dw(nx,prefix+'.g'))
        x = x + mask*self.dw(z,prefix+'.o')
        h = self.hc(rms(x),prefix+'.hc')
        response = np.sqrt(np.sum((mask*h)**2,axis=(0,1),keepdims=True)+1e-6)
        gamma = self.p(prefix+'.grn.gamma',(x.shape[-1],),0.05)
        beta = self.p(prefix+'.grn.beta',(x.shape[-1],),0.01)
        return x + mask*(h+gamma*h*response/(response.mean()+1e-6)+beta)

    def attend(self,x,mask,i):
        key = f'attention.{i}'
        z = rms(x)
        # Four query heads share one KV head, but V is wider than Q/K.
        q = rms(self.linear(z,key+'.q',4*self.qk).reshape(-1,4,self.qk))
        k = rms(self.linear(z,key+'.k',self.qk))
        pos = np.arange(len(x),dtype=np.float32)
        q,k = rope(q,pos),rope(k,pos)
        v = self.linear(z,key+'.v',self.value)
        logits = (q.transpose(1,0,2) @ k.T) / np.float32(np.sqrt(self.qk))
        logits[...,~mask] = -np.inf
        a = (softmax(logits) @ v).transpose(1,0,2).reshape(len(x),4*self.value)
        a *= sigmoid(self.linear(z,key+'.sigmoid',4*self.value))
        post = rms(self.linear(a,key+'.out',self.hidden))
        gate = sigmoid(self.p(key+'.residual_logit',(1,),0.10))
        x = x + mask[:,None]*gate*post
        return x + mask[:,None]*self.hc(rms(x),key+'.hc')

    def neck_block(self, x, key):
        return x + self.linear(self.dw(silu(rms(x)),key+'.dw'),key+'.pw',x.shape[-1])

    def __call__(self,image):
        x, hw = letterbox(image,self.size)
        f1,s4,s8,s16,f5 = self.stem(x,hw)
        mask = valid_mask(f5.shape[0],32,hw)
        x = silu(f5)
        for i in range(self.body_count):
            x = self.body(x,mask[...,None],i)
        x = x.reshape(-1,self.hidden)
        n = len(x)
        z = np.concatenate([x,self.p('registers',(4,self.hidden),0.05)],axis=0)
        token_mask = np.r_[mask.reshape(-1),[True]*4]
        levels = []
        for i in range(self.attention_count):
            levels.append(z[:n])
            z = self.attend(z,token_mask,i)
        e = rms(z[:n])
        for i, level in enumerate(levels):
            e += rms(level)*self.p(f'level.{i}',(self.hidden,),0.03)
        e = (e*token_mask[:n,None]).reshape(f5.shape)
        # First fusion: E + S16 at stride 16; second fusion: T + S8 at stride 8.
        t = self.neck_block(up2(self.linear(e,'neck.E',self.dense))+
                            self.linear(s16,'neck.S16',self.dense),'neck.stage1')
        d = up2(t) + self.linear(s8,'neck.S8',self.dense)
        for i in range(3):
            d = self.neck_block(d,f'neck.stage2.{i}')
        d = silu(rms(d))
        p = up2(d) + self.linear(s4,'mask.S4',self.dense)
        c = d
        for i in range(2):
            p = self.neck_block(p,f'mask.P{i}')
            c = self.neck_block(c,f'mask.C{i}')
        p = self.linear(silu(rms(p)),'mask.P',32)
        c = self.linear(silu(rms(c)),'mask.C',32)
        raw = self.linear(d,'detect',10) # demo: 2 categories × (score, w,h, dx,dy)
        raw = raw.reshape(*d.shape[:2],2,5)
        return dict(F1=f1,S4=s4,S8=s8,S16=s16,F5=f5,
                    E=e,T32=t,D=d,P=p,C=c,detector=raw,
                    valid_coarse=mask,valid_dense=valid_mask(d.shape[0],8,hw))

    def region_tokens(self, out, picks):
        """picks: iterable of (row, col, box_xyxy_normalized_to_canvas)."""
        regions = []
        e,d = out['E'],out['D']
        for i,j,box in picks:
            box = np.array(box,dtype=np.float32)
            if box.shape != (4,) or not np.isfinite(box).all():
                raise ValueError('expected finite XYXY box')
            side = e.shape[0]
            x0,y0 = np.clip(np.floor(box[:2]*side).astype(int),0,side-1)
            x1,y1 = np.clip(np.ceil(box[2:]*side).astype(int),0,side)
            if x1 <= x0 or y1 <= y0:
                raise ValueError('empty region at coarse scale')
            pool = e[y0:y1,x0:x1].mean(axis=(0,1))
            phase = box[:,None] * np.float32(np.pi)*(2**np.arange(8,dtype=np.float32))
            fourier = np.concatenate([np.sin(phase),np.cos(phase)],axis=-1).reshape(-1)
            local = np.r_[d[i,j],fourier]
            regions.append(rms(self.linear(local,'region.project',self.hidden)+
                               self.linear(pool,'region.pool',self.hidden)))
        e_tokens = e.reshape(-1,self.hidden)
        region_tokens = np.stack(regions) if regions else np.empty((0,self.hidden),dtype=e.dtype)
        return np.concatenate([e_tokens,region_tokens])


def instance_mask(out,row,col):
    return sigmoid(out['P'] @ out['C'][row,col])


def decode_dense(raw, i, j, category):
    """Single-cell example with canvas-normalized x1,y1,x2,y2."""
    score,w,h,dx,dy = raw[i,j,category]
    side = raw.shape[0]
    x,y = j+dx,i+dy
    box = ((x-abs(w)/2)/side,(y-abs(h)/2)/side,(x+abs(w)/2)/side,(y+abs(h)/2)/side)
    return float(sigmoid(score)), tuple(float(v) for v in box)


def ctc_greedy(logits, alphabet):
    """Class 0 blank; merge runs first, then discard blank."""
    if logits.ndim != 2 or logits.shape[1] != len(alphabet)+1:
        raise ValueError('wrong logits dimensions for alphabet')
    previous = -1
    result = []
    for symbol in logits.argmax(axis=1):
        if symbol != previous and symbol != 0:
            result.append(alphabet[symbol-1])
        previous = symbol
    return ''.join(result)


def toy_image():
    image = np.full((90,140,3),32,dtype=np.uint8)
    image[18:67,37:96] = [255,150,35]
    return image


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--full-shapes', action='store_true')
    parser.add_argument('--full-depth', action='store_true')
    parser.add_argument('--image')
    args = parser.parse_args()
    if args.image:
        from PIL import Image, ImageOps
        with Image.open(args.image) as im:
            image = np.asarray(ImageOps.exif_transpose(im).convert('RGB'))
    else:
        image = toy_image()
    kwargs = dict(size=512,channels=(32,64,128,256,512)) if args.full_shapes else {}
    if args.full_depth:
        kwargs.update(body_count=16,attention_count=12)
    model = Reference(**kwargs)
    out = model(image)
    row,col = np.unravel_index(np.where(out['valid_dense'],out['detector'][...,0,0],-np.inf).argmax(),out['valid_dense'].shape)
    score,box = decode_dense(out['detector'],row,col,0)
    memory = model.region_tokens(out,[(row,col,(.20,.20,.65,.55))])
    print(json.dumps(dict(warning="random weights; scores have no semantic meaning",
          shapes={k:v.shape for k,v in out.items()},
          cross_attention_example=memory.shape,mask_example=instance_mask(out,row,col).shape,
          single_cell_example=dict(row=int(row),col=int(col),score=score,box=box)),indent=2))


if __name__=='__main__':
    main()
